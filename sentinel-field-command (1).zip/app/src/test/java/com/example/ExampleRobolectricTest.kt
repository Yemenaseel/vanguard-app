package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.UserRole
import com.example.security.AuthManager
import com.example.security.KeyStoreHelper
import kotlinx.coroutines.flow.first
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun testAppNameResource() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Vanguard Roll-Call", appName)
  }

  @Test
  fun testRbacAuthentication() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val authManager = AuthManager(context)

    // Admin Authentication with default PIN 9999
    val adminRole = authManager.authenticate("9999", "العقيد / حسام")
    assertEquals(UserRole.ROLE_ADMIN, adminRole)
    assertTrue(authManager.canPerformManualRollCall())
    assertTrue(authManager.canAddOrEditSoldier())
    assertTrue(authManager.canExportPdfReports())

    // Recorder Authentication with default PIN 1111
    val recorderRole = authManager.authenticate("1111", "الملازم / طارق")
    assertEquals(UserRole.ROLE_RECORDER, recorderRole)
    assertFalse(authManager.canPerformManualRollCall())
    assertFalse(authManager.canAddOrEditSoldier())
    assertFalse(authManager.canExportPdfReports())
    assertTrue(authManager.canAccessCameraScanner())
  }

  @Test
  fun testSecureTokenGenerationAndVerification() {
    val token = KeyStoreHelper.generateSecureQrToken()
    assertNotNull(token)
    assertTrue(token.startsWith("MIL-"))
    assertTrue(KeyStoreHelper.verifyQrTokenSignature(token))
    assertFalse(KeyStoreHelper.verifyQrTokenSignature("PLAINTEXT_CIVILIAN_CODE"))
  }

  @Test
  fun testScannerViewModelDebounceAndTorch() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val authManager = AuthManager(context)
    val database = com.example.data.db.AppDatabase.getInstance(context)
    val repository = com.example.data.repository.RollCallRepository(
        database = database,
        soldierDao = database.soldierDao(),
        attendanceDao = database.attendanceDao(),
        unitDao = database.unitDao()
    )
    val scannerViewModel = com.example.ui.scanner.ScannerViewModel(repository, authManager)

    // Initial states
    assertFalse(scannerViewModel.isTorchEnabled.value)
    assertEquals(0, scannerViewModel.sessionScanCount.value)

    // Toggle Torch
    scannerViewModel.toggleTorch()
    assertTrue(scannerViewModel.isTorchEnabled.value)
    scannerViewModel.toggleTorch()
    assertFalse(scannerViewModel.isTorchEnabled.value)

    // Clear alert and last scanned
    scannerViewModel.clearScanAlert()
    assertEquals(null, scannerViewModel.scanAlertMessage.value)
  }

  @Test
  fun testSupportFactoryCreation() {
    val factory = com.example.data.db.AppDatabase.createSupportFactory("9999")
    assertNotNull(factory)
  }

  @Test
  fun testAddUnitAndTransferSoldier() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val database = com.example.data.db.AppDatabase.getInstance(context)
    val repository = com.example.data.repository.RollCallRepository(
        database = database,
        soldierDao = database.soldierDao(),
        attendanceDao = database.attendanceDao(),
        unitDao = database.unitDao()
    )

    val newUnitId = repository.addUnit("كتيبة الصاعقة والمظلات (Airborne Bn)", "العقيد / سامر", "ABN-06")
    assertTrue(newUnitId > 0)

    val soldier = com.example.data.model.SoldierEntity(
        militaryId = "MIL-99991",
        fullName = "خالد مصطفى",
        rank = "عريف",
        unitId = 1,
        bloodType = "O+",
        assignedWeapon = "M4A1",
        qrToken = "MIL-TEST-TRANSFER-TOKEN"
    )
    repository.addSoldier(soldier)

    val transferSuccess = repository.transferSoldierToUnit("MIL-99991", newUnitId)
    assertTrue(transferSuccess)

    val updatedSoldier = database.soldierDao().findByMilitaryId("MIL-99991")
    assertNotNull(updatedSoldier)
    assertEquals(newUnitId, updatedSoldier?.unitId)

    // Test Room transaction: edit unit and reassign soldier
    val txSuccess = repository.updateUnitAndReassignSoldiersTransaction(
        unitId = newUnitId,
        newName = "لواء التدخل السريع المحمول جواً",
        commanderName = "العميد / سامر عزيز",
        codeSymbol = "QRF-01",
        soldierIdsToReassign = listOf("MIL-99991")
    )
    assertTrue(txSuccess)

    val updatedUnit = database.unitDao().getUnitById(newUnitId)
    assertNotNull(updatedUnit)
    assertEquals("لواء التدخل السريع المحمول جواً", updatedUnit?.unitName)
  }

  @Test
  fun testSettingsDataStorePersistence() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dataStore = com.example.data.settings.SettingsDataStore(context)

    // 1. Attendance Timing
    val timing = com.example.data.settings.AttendanceTimingSettings(
        startTime = "06:30",
        endTime = "08:15",
        allowRepeatScan = true,
        alertOnRepeatScan = true,
        defaultUnmarkedStatus = "ABSENT"
    )
    dataStore.updateAttendanceTiming(timing)

    // 2. Card Template
    val template = com.example.data.settings.CardTemplateSettings(
        orgName = "قيادة القوات الخاصة",
        showCrest = true,
        showSoldierName = true,
        showMilitaryId = true,
        showQrCode = true,
        showBlood = true,
        showWeapon = true,
        templateColor = "CAMO"
    )
    dataStore.updateCardTemplate(template)

    // Verify
    val savedTiming = dataStore.attendanceTimingFlow.first()
    assertEquals("06:30", savedTiming.startTime)
    assertEquals("08:15", savedTiming.endTime)
    assertTrue(savedTiming.allowRepeatScan)

    val savedTemplate = dataStore.cardTemplateFlow.first()
    assertEquals("قيادة القوات الخاصة", savedTemplate.orgName)
    assertEquals("CAMO", savedTemplate.templateColor)
  }
}

