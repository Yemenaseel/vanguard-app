package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MilitaryDarkColorScheme = darkColorScheme(
    primary = TacticalPrimary,
    onPrimary = TacticalOnPrimary,
    primaryContainer = TacticalPrimaryContainer,
    onPrimaryContainer = TacticalOnPrimaryContainer,
    secondary = TacticalGold,
    onSecondary = Color.Black,
    secondaryContainer = TacticalGoldContainer,
    onSecondaryContainer = TacticalOnGoldContainer,
    tertiary = TacticalSecondary,
    background = TacticalDarkBackground,
    surface = TacticalDarkSurface,
    surfaceVariant = TacticalDarkSurfaceVariant,
    onBackground = Color(0xFFE2EBE3),
    onSurface = Color(0xFFE2EBE3),
    onSurfaceVariant = Color(0xFFB0BFB2),
    outline = TacticalCardBorder,
    error = TacticalError,
    onError = TacticalOnError
)

private val MilitaryLightColorScheme = lightColorScheme(
    primary = Color(0xFF2E4D34),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0E8D4),
    onPrimaryContainer = Color(0xFF0F2414),
    secondary = Color(0xFF8A6D14),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFF0C2),
    onSecondaryContainer = Color(0xFF2E2200),
    background = Color(0xFFF4F7F4),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE4EDE5),
    onBackground = Color(0xFF141E16),
    onSurface = Color(0xFF141E16),
    onSurfaceVariant = Color(0xFF3B483D),
    outline = Color(0xFF758577),
    error = TacticalError,
    onError = TacticalOnError
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our crisp tactical military theme by default
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) MilitaryDarkColorScheme else MilitaryLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
