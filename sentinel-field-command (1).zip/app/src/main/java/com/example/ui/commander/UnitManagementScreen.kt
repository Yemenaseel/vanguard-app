package com.example.ui.commander

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SoldierEntity
import com.example.data.model.UnitEntity
import com.example.data.repository.RollCallRepository
import com.example.security.AuthManager
import com.example.ui.components.TacticalHeader
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.TacticalCardBorder
import com.example.ui.theme.TacticalGold
import kotlinx.coroutines.launch

/**
 * Dedicated Screen for Commanders to Manage Military Units.
 * Allows commanders to:
 * 1. View all military units with real-time troop counts.
 * 2. Add new units (Battalions, Companies, Platoons).
 * 3. Edit existing unit names, commander callsigns, and tactical symbols.
 * 4. Reassign soldiers between units using an atomic database transaction (@Transaction).
 * 5. Delete units safely with transactional soldier re-assignment.
 */
@Composable
fun UnitManagementScreen(
    authManager: AuthManager,
    repository: RollCallRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val officerName by authManager.officerName.collectAsState()
    val units by repository.getAllUnits().collectAsState(initial = emptyList())
    val allSoldiers by repository.getAllSoldiersIncludingInactive().collectAsState(initial = emptyList())

    var searchQuery by remember { mutableStateOf("") }
    var showAddUnitDialog by remember { mutableStateOf(false) }
    var unitToEdit by remember { mutableStateOf<UnitEntity?>(null) }
    var unitToReassignSoldiers by remember { mutableStateOf<UnitEntity?>(null) }
    var unitToDelete by remember { mutableStateOf<UnitEntity?>(null) }

    val filteredUnits = remember(units, searchQuery) {
        if (searchQuery.isBlank()) units
        else units.filter {
            it.unitName.contains(searchQuery, ignoreCase = true) ||
                    it.commanderName.contains(searchQuery, ignoreCase = true) ||
                    it.codeSymbol.contains(searchQuery, ignoreCase = true)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TacticalHeader(
                title = "إدارة التشكيلات والوحدات العسكرية",
                subtitle = "TACTICAL UNIT COMMAND & SOLDIER REASSIGNMENT",
                officerName = officerName,
                roleTitle = "قائد اللواء",
                onLogout = onNavigateBack,
                extraAction = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = TacticalGold
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddUnitDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_unit_main_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Text("إضافة وحدة جديدة", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Metrics Bar
            UnitMetricsHeader(
                totalUnits = units.size,
                totalSoldiers = allSoldiers.size
            )

            // Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث عن وحدة، سرية، أو قائد...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // Units List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 96.dp, top = 4.dp)
            ) {
                items(filteredUnits, key = { it.unitId }) { unit ->
                    val soldiersInThisUnit = allSoldiers.filter { it.unitId == unit.unitId }

                    UnitCardItem(
                        unit = unit,
                        soldierCount = soldiersInThisUnit.size,
                        onEditName = { unitToEdit = unit },
                        onReassignSoldiers = { unitToReassignSoldiers = unit },
                        onDeleteUnit = { unitToDelete = unit }
                    )
                }
            }
        }
    }

    // 1. Add Unit Dialog
    if (showAddUnitDialog) {
        AddUnitDialog(
            onDismiss = { showAddUnitDialog = false },
            onSaveUnit = { name, commander, code ->
                coroutineScope.launch {
                    val id = repository.addUnit(name, commander, code)
                    showAddUnitDialog = false
                    snackbarHostState.showSnackbar("✅ تم إنشاء الوحدة بنجاح برقم تعريفي #$id")
                }
            }
        )
    }

    // 2. Edit Unit Name Dialog (Room Transaction)
    unitToEdit?.let { unit ->
        EditUnitDetailsDialog(
            unit = unit,
            onDismiss = { unitToEdit = null },
            onSave = { updatedName, updatedCommander, updatedCode ->
                coroutineScope.launch {
                    val success = repository.updateUnitAndReassignSoldiersTransaction(
                        unitId = unit.unitId,
                        newName = updatedName,
                        commanderName = updatedCommander,
                        codeSymbol = updatedCode,
                        soldierIdsToReassign = emptyList()
                    )
                    unitToEdit = null
                    if (success) {
                        snackbarHostState.showSnackbar("✅ تم تحديث بيانات الوحدة باسم: $updatedName عبر معاملة ذرية (@Transaction)")
                    } else {
                        snackbarHostState.showSnackbar("تعذر تعديل الوحدة")
                    }
                }
            }
        )
    }

    // 3. Reassign Soldiers Dialog (Multi-Soldier Atomic Room Transaction)
    unitToReassignSoldiers?.let { unit ->
        val unitSoldiers = allSoldiers.filter { it.unitId == unit.unitId }
        val targetUnits = units.filter { it.unitId != unit.unitId }

        ReassignSoldiersBatchDialog(
            sourceUnit = unit,
            availableSoldiers = unitSoldiers,
            targetUnits = targetUnits,
            onDismiss = { unitToReassignSoldiers = null },
            onExecuteReassignment = { selectedSoldierIds, targetUnitId, targetUnitName ->
                coroutineScope.launch {
                    val success = repository.reassignSoldiersBetweenUnitsTransaction(
                        soldierIds = selectedSoldierIds,
                        targetUnitId = targetUnitId
                    )
                    unitToReassignSoldiers = null
                    if (success) {
                        snackbarHostState.showSnackbar(
                            "✅ تم نقل ${selectedSoldierIds.size} فرد إلى [$targetUnitName] بنجاح في معاملة ذرية بقاعدة البيانات (@Transaction)"
                        )
                    } else {
                        snackbarHostState.showSnackbar("فشلت عملية إعادة التعيين")
                    }
                }
            }
        )
    }

    // 4. Delete Unit Dialog (Safe Migration Transaction)
    unitToDelete?.let { unit ->
        val otherUnits = units.filter { it.unitId != unit.unitId }
        var selectedFallbackUnitId by remember { mutableStateOf(otherUnits.firstOrNull()?.unitId) }

        AlertDialog(
            onDismissRequest = { unitToDelete = null },
            title = {
                Text(
                    text = "حذف الوحدة العسكرية",
                    fontWeight = FontWeight.Bold,
                    color = StatusAbsent
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("هل أنت متأكد من رغبتك في حذف: \"${unit.unitName}\"؟")
                    val count = allSoldiers.count { it.unitId == unit.unitId }
                    if (count > 0 && otherUnits.isNotEmpty()) {
                        Text(
                            text = "تحتوي هذه الوحدة على $count فرد. سيتم نقلهم جميعاً تلقائياً إلى الوحدة البديلة ضمن معاملة ذرية موحدة (@Transaction):",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        otherUnits.forEach { fallback ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedFallbackUnitId = fallback.unitId }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                androidx.compose.material3.RadioButton(
                                    selected = selectedFallbackUnitId == fallback.unitId,
                                    onClick = { selectedFallbackUnitId = fallback.unitId }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(fallback.unitName, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    } else if (count > 0) {
                        Text(
                            "تحذير: لا توجد وحدات أخرى لنقل الأفراد إليها!",
                            color = StatusAbsent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val fallbackId = selectedFallbackUnitId
                        if (fallbackId != null) {
                            coroutineScope.launch {
                                repository.deleteUnitAndReassignSoldiersTransaction(
                                    unitIdToDelete = unit.unitId,
                                    fallbackUnitId = fallbackId
                                )
                                unitToDelete = null
                                snackbarHostState.showSnackbar("تم حذف الوحدة ونقل أفرادها بالكامل بنجاح")
                            }
                        } else {
                            unitToDelete = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAbsent)
                ) {
                    Text("تأكيد الحذف والنقل")
                }
            },
            dismissButton = {
                TextButton(onClick = { unitToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun UnitMetricsHeader(
    totalUnits: Int,
    totalSoldiers: Int
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$totalUnits",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = TacticalGold
                )
                Text(
                    text = "إجمالي التشكيلات",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(
                modifier = Modifier
                    .height(36.dp)
                    .width(1.dp)
                    .background(TacticalCardBorder)
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$totalSoldiers",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "القوة الإجمالية المسجلة",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Box(
                modifier = Modifier
                    .height(36.dp)
                    .width(1.dp)
                    .background(TacticalCardBorder)
            )

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val avg = if (totalUnits > 0) totalSoldiers / totalUnits else 0
                Text(
                    text = "$avg",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = StatusPresent
                )
                Text(
                    text = "متوسط القوة / وحدة",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun UnitCardItem(
    unit: UnitEntity,
    soldierCount: Int,
    onEditName: () -> Unit,
    onReassignSoldiers: () -> Unit,
    onDeleteUnit: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("unit_item_${unit.unitId}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Unit Title & Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = TacticalGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = unit.unitName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = TacticalGold.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = unit.codeSymbol,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TacticalGold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "• القائد: ${unit.commanderName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Troop strength pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "$soldierCount فرد",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(TacticalCardBorder.copy(alpha = 0.5f))
            )

            // Tactical Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Edit Unit Name Button
                Button(
                    onClick = onEditName,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل الاسم", style = MaterialTheme.typography.labelMedium)
                }

                // 2. Reassign Soldiers Button
                Button(
                    onClick = onReassignSoldiers,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نقل الأفراد", style = MaterialTheme.typography.labelMedium)
                }

                // 3. Delete Unit Button
                IconButton(
                    onClick = onDeleteUnit,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف الوحدة",
                        tint = StatusAbsent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Dialog for Editing Existing Unit Names and Command Details.
 */
@Composable
private fun EditUnitDetailsDialog(
    unit: UnitEntity,
    onDismiss: () -> Unit,
    onSave: (name: String, commander: String, code: String) -> Unit
) {
    var unitName by remember { mutableStateOf(unit.unitName) }
    var commanderName by remember { mutableStateOf(unit.commanderName) }
    var codeSymbol by remember { mutableStateOf(unit.codeSymbol) }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, TacticalGold)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = TacticalGold)
                        }
                        Text(
                            text = "تعديل اسم وبيانات الوحدة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TacticalGold.copy(alpha = 0.1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TacticalGold.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "🔒 سيتم تحديث اسم وسجلات الوحدة عبر معاملة ذرية مشفرة بقاعدة البيانات (@Transaction).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                OutlinedTextField(
                    value = unitName,
                    onValueChange = {
                        unitName = it
                        error = null
                    },
                    label = { Text("اسم الوحدة / الكتيبة *") },
                    placeholder = { Text("مثال: كتيبة الدروع الملكية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    isError = error != null
                )

                OutlinedTextField(
                    value = commanderName,
                    onValueChange = { commanderName = it },
                    label = { Text("اسم القائد / النداء الميداني") },
                    placeholder = { Text("مثال: العقيد / حسام الدين") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = codeSymbol,
                    onValueChange = { codeSymbol = it },
                    label = { Text("الرمز التكتيكي (Code Symbol)") },
                    placeholder = { Text("مثال: ARM-03") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                error?.let {
                    Text(it, color = StatusAbsent, style = MaterialTheme.typography.bodySmall)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            if (unitName.isBlank()) {
                                error = "يرجى كتابة اسم الوحدة"
                            } else {
                                onSave(unitName.trim(), commanderName.trim(), codeSymbol.trim())
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TacticalGold)
                    ) {
                        Text("حفظ التعديل", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Dialog for Reassigning Soldiers Between Units using an Atomic Room Database Transaction.
 */
@Composable
private fun ReassignSoldiersBatchDialog(
    sourceUnit: UnitEntity,
    availableSoldiers: List<SoldierEntity>,
    targetUnits: List<UnitEntity>,
    onDismiss: () -> Unit,
    onExecuteReassignment: (selectedSoldierIds: List<String>, targetUnitId: Long, targetUnitName: String) -> Unit
) {
    var selectedTargetUnitId by remember { mutableStateOf(targetUnits.firstOrNull()?.unitId) }
    val selectedSoldierIds = remember { mutableStateListOf<String>() }
    var filterQuery by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val filteredSoldiers = remember(availableSoldiers, filterQuery) {
        if (filterQuery.isBlank()) availableSoldiers
        else availableSoldiers.filter {
            it.fullName.contains(filterQuery, ignoreCase = true) ||
                    it.militaryId.contains(filterQuery, ignoreCase = true) ||
                    it.rank.contains(filterQuery, ignoreCase = true)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, TacticalCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null, tint = TacticalGold)
                        }
                        Column {
                            Text(
                                text = "إعادة تعيين ونقل الأفراد",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "من: ${sourceUnit.unitName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TacticalGold
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                // Transaction Notice
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                ) {
                    Text(
                        text = "⚡ معاملة ذرية (@Transaction): سيتم نقل كافة الأفراد المحددين وتحديث قيود التمام في عملية واحدة لا تقبل التجزئة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                // Target Unit Selector
                Text(
                    text = "حدد الوحدة العسكرية المستهدفة للنقل إليها:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                if (targetUnits.isEmpty()) {
                    Text("لا توجد وحدات عسكرية أخرى متاحة للنقل إليها.", color = StatusAbsent)
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        targetUnits.forEach { unit ->
                            val isSelected = selectedTargetUnitId == unit.unitId
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else TacticalCardBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedTargetUnitId = unit.unitId }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = unit.unitName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                // Soldiers Filter and Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "اختر الأفراد المطلوب نقلهم (${selectedSoldierIds.size} من ${availableSoldiers.size}):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    TextButton(
                        onClick = {
                            if (selectedSoldierIds.size == availableSoldiers.size) {
                                selectedSoldierIds.clear()
                            } else {
                                selectedSoldierIds.clear()
                                selectedSoldierIds.addAll(availableSoldiers.map { it.militaryId })
                            }
                        }
                    ) {
                        Text(if (selectedSoldierIds.size == availableSoldiers.size) "إلغاء التحديد" else "تحديد الكل")
                    }
                }

                // Search field inside dialog
                OutlinedTextField(
                    value = filterQuery,
                    onValueChange = { filterQuery = it },
                    placeholder = { Text("بحث عن فرد بالاسم أو الرقم...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                // List of soldiers to pick
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .border(1.dp, TacticalCardBorder, RoundedCornerShape(8.dp))
                ) {
                    if (filteredSoldiers.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("لا يوجد أفراد مسجلون بهذه الوحدة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(4.dp)
                        ) {
                            items(filteredSoldiers, key = { it.militaryId }) { soldier ->
                                val isChecked = selectedSoldierIds.contains(soldier.militaryId)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            if (isChecked) selectedSoldierIds.remove(soldier.militaryId)
                                            else selectedSoldierIds.add(soldier.militaryId)
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { checked ->
                                                if (checked) selectedSoldierIds.add(soldier.militaryId)
                                                else selectedSoldierIds.remove(soldier.militaryId)
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = TacticalGold)
                                        )
                                        Column {
                                            Text(
                                                text = "${soldier.rank} / ${soldier.fullName}",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "رقم عسكري: ${soldier.militaryId} • سلاح: ${soldier.assignedWeapon}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                errorMessage?.let {
                    Text(it, color = StatusAbsent, style = MaterialTheme.typography.bodySmall)
                }

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء")
                    }

                    Button(
                        onClick = {
                            val targetId = selectedTargetUnitId
                            val targetName = targetUnits.find { it.unitId == targetId }?.unitName ?: "الوحدة المحددة"
                            if (selectedSoldierIds.isEmpty()) {
                                errorMessage = "يرجى اختيار فرد واحد على الأقل للنقل"
                            } else if (targetId == null) {
                                errorMessage = "يرجى اختيار الوحدة المستهدفة"
                            } else {
                                onExecuteReassignment(selectedSoldierIds.toList(), targetId, targetName)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        enabled = selectedSoldierIds.isNotEmpty() && selectedTargetUnitId != null
                    ) {
                        Text("تنفيذ النقل (${selectedSoldierIds.size})", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
