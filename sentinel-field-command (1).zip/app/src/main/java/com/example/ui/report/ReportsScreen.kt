package com.example.ui.report

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AttendanceEntity
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSummary
import com.example.data.model.SoldierAttendanceItem
import com.example.data.model.UnitAttendanceSummary
import com.example.data.repository.RollCallRepository
import com.example.security.AuthManager
import com.example.ui.components.TacticalHeader
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.TacticalCardBorder
import com.example.ui.theme.TacticalGold
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class PeriodOption(val label: String) {
    TODAY("اليوم"),
    YESTERDAY("أمس"),
    THIS_WEEK("هذا الأسبوع"),
    THIS_MONTH("هذا الشهر"),
    CUSTOM("تحديد تاريخ 📅")
}

enum class ReportCategory(val label: String) {
    DAILY("تقرير التحضير اليومي"),
    PERIOD("تقرير فترة محددة"),
    UNMARKED_ONLY("قائمة من لم يتم تحضيرهم"),
    BY_UNIT("إجمالي الحضور حسب الوحدة/المجموعة"),
    SOLDIER_HISTORY("سجل تحضير فرد معين")
}

@Composable
fun ReportsScreen(
    authManager: AuthManager,
    repository: RollCallRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val officerName by authManager.officerName.collectAsState()
    val units by repository.getAllUnits().collectAsState(initial = emptyList())

    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var selectedPeriod by remember { mutableStateOf(PeriodOption.TODAY) }
    var activeDate by remember { mutableStateOf(todayStr) }
    var activePeriodLabel by remember { mutableStateOf("تحضير يوم $todayStr") }
    var selectedUnitId by remember { mutableStateOf<Long?>(null) }
    var selectedCategory by remember { mutableStateOf(ReportCategory.DAILY) }
    var searchQuery by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    var records by remember { mutableStateOf<List<SoldierAttendanceItem>>(emptyList()) }
    var summary by remember { mutableStateOf(AttendanceSummary()) }
    var unitSummaries by remember { mutableStateOf<List<UnitAttendanceSummary>>(emptyList()) }

    var selectedSoldierForHistory by remember { mutableStateOf<SoldierAttendanceItem?>(null) }
    var soldierHistoryLogs by remember { mutableStateOf<List<AttendanceEntity>>(emptyList()) }
    var isLoadingHistory by remember { mutableStateOf(false) }

    fun refreshData() {
        coroutineScope.launch {
            isLoading = true
            try {
                val allRecords = repository.getAllSoldiersForReport(activeDate, selectedUnitId)
                records = allRecords

                val total = allRecords.size
                val present = allRecords.count { it.attendanceStatus == AttendanceStatus.PRESENT }
                val absent = allRecords.count { it.attendanceStatus == AttendanceStatus.ABSENT }
                val sick = allRecords.count { it.attendanceStatus == AttendanceStatus.SICK }
                val leave = allRecords.count { it.attendanceStatus == AttendanceStatus.LEAVE }
                val mission = allRecords.count { it.attendanceStatus == AttendanceStatus.MISSION }
                val unmarked = allRecords.count { it.attendanceStatus == AttendanceStatus.UNMARKED }

                summary = AttendanceSummary(
                    totalSoldiers = total,
                    presentCount = present,
                    absentCount = absent,
                    sickCount = sick,
                    leaveCount = leave,
                    missionCount = mission,
                    unmarkedCount = unmarked
                )

                // Fetch Unit Breakdown
                try {
                    unitSummaries = repository.getAttendanceSummaryByUnit(activeDate).first()
                } catch (e: Exception) {
                    unitSummaries = emptyList()
                }
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(activeDate, selectedUnitId) {
        refreshData()
    }

    // Load soldier history when chosen
    fun loadSoldierHistory(soldier: SoldierAttendanceItem) {
        selectedSoldierForHistory = soldier
        coroutineScope.launch {
            isLoadingHistory = true
            try {
                soldierHistoryLogs = repository.getSoldierAttendanceHistory(soldier.militaryId)
            } finally {
                isLoadingHistory = false
            }
        }
    }

    // Date Picker Dialog Launcher
    fun showDatePicker() {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val picked = "%04d-%02d-%02d".format(year, month + 1, dayOfMonth)
                activeDate = picked
                activePeriodLabel = "تحضير يوم $picked"
                selectedPeriod = PeriodOption.CUSTOM
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TacticalHeader(
                title = "مركز التقارير والإحصائيات العسكرية",
                subtitle = "TACTICAL ROLL-CALL AUDIT & ANALYTICS",
                officerName = officerName,
                roleTitle = "قائد العمليات / المشرف",
                onLogout = onNavigateBack,
                extraAction = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = TacticalGold
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Period Selector Strip
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "اختيار الفترة الزمنية:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = activePeriodLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = TacticalGold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(PeriodOption.values()) { option ->
                            val isSelected = selectedPeriod == option
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else TacticalCardBorder
                                ),
                                modifier = Modifier
                                    .height(34.dp)
                                    .clickable {
                                        selectedPeriod = option
                                        when (option) {
                                            PeriodOption.TODAY -> {
                                                activeDate = todayStr
                                                activePeriodLabel = "تحضير اليوم ($todayStr)"
                                            }
                                            PeriodOption.YESTERDAY -> {
                                                val cal = Calendar.getInstance()
                                                cal.add(Calendar.DAY_OF_YEAR, -1)
                                                activeDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                                activePeriodLabel = "تحضير أمس ($activeDate)"
                                            }
                                            PeriodOption.THIS_WEEK -> {
                                                val cal = Calendar.getInstance()
                                                cal.add(Calendar.DAY_OF_YEAR, -6)
                                                val weekStart = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                                activeDate = todayStr
                                                activePeriodLabel = "هذا الأسبوع ($weekStart إلى $todayStr)"
                                            }
                                            PeriodOption.THIS_MONTH -> {
                                                val cal = Calendar.getInstance()
                                                cal.set(Calendar.DAY_OF_MONTH, 1)
                                                val monthStart = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                                activeDate = todayStr
                                                activePeriodLabel = "هذا الشهر ($monthStart إلى $todayStr)"
                                            }
                                            PeriodOption.CUSTOM -> showDatePicker()
                                        }
                                    }
                                    .testTag("period_option_${option.name}")
                            ) {
                                Box(
                                    modifier = Modifier.padding(horizontal = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = option.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Unit Selection Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (selectedUnitId == null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (selectedUnitId == null) MaterialTheme.colorScheme.primary else TacticalCardBorder
                                ),
                                modifier = Modifier
                                    .height(32.dp)
                                    .clickable { selectedUnitId = null }
                            ) {
                                Box(modifier = Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "كافة الوحدات التكتيكية",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (selectedUnitId == null) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedUnitId == null) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        items(units, key = { it.unitId }) { unit ->
                            val isSelected = selectedUnitId == unit.unitId
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else TacticalCardBorder
                                ),
                                modifier = Modifier
                                    .height(32.dp)
                                    .clickable { selectedUnitId = unit.unitId }
                            ) {
                                Box(modifier = Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = unit.unitName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 2. Metrics Summary Card (Exactly formatted as user requested)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ملخص التحضير • $activePeriodLabel",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "نسبة الجاهزية: ${"%.1f".format(summary.presentPercentage)}%",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = TacticalGold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricBox(icon = "👥", label = "إجمالي الأفراد", value = "${summary.totalSoldiers}", color = MaterialTheme.colorScheme.onSurface)
                        MetricBox(icon = "✅", label = "تم التحضير", value = "${summary.presentCount}", color = StatusPresent)
                        val unCount = summary.absentCount + summary.unmarkedCount
                        MetricBox(icon = "❌", label = "لم يتم التحضير", value = "$unCount", color = StatusAbsent)
                        MetricBox(icon = "📈", label = "نسبة التحضير", value = "${"%.1f".format(summary.presentPercentage)}%", color = TacticalGold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { (summary.presentPercentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = StatusPresent,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }

            // 3. Export Action Bar (📄 تصدير التقرير PDF & Excel)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val unitName = if (selectedUnitId != null) {
                            units.find { it.unitId == selectedUnitId }?.unitName ?: "الوحدة"
                        } else {
                            "كافة الوحدات التكتيكية"
                        }
                        val exportItems = if (selectedCategory == ReportCategory.UNMARKED_ONLY) {
                            records.filter { it.attendanceStatus == AttendanceStatus.ABSENT || it.attendanceStatus == AttendanceStatus.UNMARKED }
                        } else records

                        val uri = PdfExportManager.generateAndSaveDailyReport(
                            context = context,
                            date = activeDate,
                            commanderName = officerName,
                            unitFilterName = unitName,
                            summary = summary,
                            records = exportItems
                        )
                        if (uri != null) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("📄 تم استخراج تقرير PDF بنجاح عبر MediaStore في المستندات")
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("export_pdf_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📄 تصدير PDF",
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        val unitName = if (selectedUnitId != null) {
                            units.find { it.unitId == selectedUnitId }?.unitName ?: "الوحدة"
                        } else {
                            "كافة الوحدات التكتيكية"
                        }
                        val exportItems = if (selectedCategory == ReportCategory.UNMARKED_ONLY) {
                            records.filter { it.attendanceStatus == AttendanceStatus.ABSENT || it.attendanceStatus == AttendanceStatus.UNMARKED }
                        } else records

                        val uri = CsvExportManager.generateAndSaveCsvReport(
                            context = context,
                            date = activeDate,
                            commanderName = officerName,
                            unitFilterName = unitName,
                            summary = summary,
                            records = exportItems
                        )
                        if (uri != null) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("📊 تم تصدير التقرير إلى Excel (CSV) بنجاح في التنزيلات")
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .testTag("export_excel_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Icon(
                        imageVector = Icons.Default.TableChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📊 تصدير Excel",
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 4. Report Types Strip (The 5 requested reports)
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                Text(
                    text = "نوع التقرير المستخرج:",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ReportCategory.values()) { category ->
                        val isSelected = selectedCategory == category
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) MaterialTheme.colorScheme.primary else TacticalCardBorder
                            ),
                            modifier = Modifier
                                .height(32.dp)
                                .clickable { selectedCategory = category }
                                .testTag("report_category_${category.name}")
                        ) {
                            Box(modifier = Modifier.padding(horizontal = 10.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = category.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Search field (search by name, military ID, or rank)
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث بالاسم أو الرقم العسكري...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("report_search_field"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = TacticalCardBorder
                    )
                )
            }

            // 5. Dynamic Content Area based on Category
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (isLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else when (selectedCategory) {
                    ReportCategory.BY_UNIT -> {
                        // View: إجمالي الحضور حسب الوحدة / المجموعة
                        if (unitSummaries.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("لا توجد بيانات وحدات في هذا التاريخ", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                items(unitSummaries, key = { it.unitId }) { unitSum ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    Icon(imageVector = Icons.Default.MilitaryTech, contentDescription = null, tint = TacticalGold)
                                                    Text(text = unitSum.unitName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                                }
                                                Text(
                                                    text = "${"%.1f".format(unitSum.presentPercentage)}% نسبة الحضور",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = StatusPresent
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(text = "القوة: ${unitSum.totalSoldiers}", style = MaterialTheme.typography.labelSmall)
                                                Text(text = "حاضر: ${unitSum.presentCount}", style = MaterialTheme.typography.labelSmall, color = StatusPresent, fontWeight = FontWeight.Bold)
                                                Text(text = "غائب: ${unitSum.absentCount}", style = MaterialTheme.typography.labelSmall, color = StatusAbsent, fontWeight = FontWeight.Bold)
                                                Text(text = "إجازة: ${unitSum.leaveCount}", style = MaterialTheme.typography.labelSmall)
                                                Text(text = "مرض: ${unitSum.sickCount}", style = MaterialTheme.typography.labelSmall)
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            LinearProgressIndicator(
                                                progress = { (unitSum.presentPercentage / 100f).coerceIn(0f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(6.dp)
                                                    .clip(RoundedCornerShape(3.dp)),
                                                color = StatusPresent,
                                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    ReportCategory.SOLDIER_HISTORY -> {
                        // View: سجل تحضير فرد معين
                        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                            if (selectedSoldierForHistory == null) {
                                Text(
                                    text = "اختر فرداً لعرض سجله التاريخي التراكمي:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                                val matchingSoldiers = remember(records, searchQuery) {
                                    records.filter {
                                        if (searchQuery.isBlank()) true else {
                                            it.fullName.contains(searchQuery, ignoreCase = true) || it.militaryId.contains(searchQuery, ignoreCase = true)
                                        }
                                    }
                                }

                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    contentPadding = PaddingValues(vertical = 4.dp)
                                ) {
                                    items(matchingSoldiers, key = { it.militaryId }) { soldier ->
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { loadSoldierHistory(soldier) },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(text = soldier.fullName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                                    Text(text = "${soldier.rank} • ${soldier.militaryId}", style = MaterialTheme.typography.labelSmall, color = TacticalGold)
                                                }
                                                Icon(imageVector = Icons.Default.History, contentDescription = "عرض السجل", tint = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    }
                                }
                            } else {
                                // Display History Timeline
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "سجل التحضير: ${selectedSoldierForHistory?.fullName}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "الرقم العسكري: ${selectedSoldierForHistory?.militaryId} • الرتبة: ${selectedSoldierForHistory?.rank}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Button(
                                        onClick = { selectedSoldierForHistory = null },
                                        shape = RoundedCornerShape(6.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                    ) {
                                        Text("اختيار فرد آخر", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                if (isLoadingHistory) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                    }
                                } else if (soldierHistoryLogs.isEmpty()) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("لا توجد تسجيلات تحضير سابقة لهذا الفرد بعد", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                } else {
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.spacedBy(6.dp),
                                        contentPadding = PaddingValues(vertical = 6.dp)
                                    ) {
                                        items(soldierHistoryLogs) { log ->
                                            val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(log.timestamp))
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(text = "تاريخ: ${log.date}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                                        Text(text = "سجل بواسطة: ${log.markedByOfficerName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Text(
                                                            text = if (log.status == AttendanceStatus.PRESENT) "✅ حاضر" else "❌ ${log.status.labelAr}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (log.status == AttendanceStatus.PRESENT) StatusPresent else StatusAbsent
                                                        )
                                                        Text(text = timeFmt, style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        // Views: DAILY, PERIOD, UNMARKED_ONLY
                        val filteredRecords = remember(records, selectedCategory, searchQuery) {
                            records.filter { item ->
                                val matchesCategory = when (selectedCategory) {
                                    ReportCategory.DAILY, ReportCategory.PERIOD -> true
                                    ReportCategory.UNMARKED_ONLY -> item.attendanceStatus == AttendanceStatus.ABSENT || item.attendanceStatus == AttendanceStatus.UNMARKED
                                    else -> true
                                }
                                val matchesSearch = if (searchQuery.isBlank()) true else {
                                    item.militaryId.contains(searchQuery, ignoreCase = true) ||
                                            item.fullName.contains(searchQuery, ignoreCase = true) ||
                                            item.rank.contains(searchQuery, ignoreCase = true)
                                }
                                matchesCategory && matchesSearch
                            }
                        }

                        if (filteredRecords.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    text = if (selectedCategory == ReportCategory.UNMARKED_ONLY)
                                        "ممتاز! تم تحضير كافة الأفراد ولا يوجد متغيبون في هذا التاريخ"
                                    else
                                        "لا توجد سجلات مطابقة لمعايير البحث في هذا التاريخ",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                // Header Table Row (الفرد | الرقم | الحالة | الوقت)
                                item {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(text = "الفرد / الاسم", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                                            Text(text = "الرقم", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                                            Text(text = "الحالة", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                                            Text(text = "الوقت", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
                                        }
                                    }
                                }

                                // Data Rows
                                items(filteredRecords, key = { it.militaryId }) { item ->
                                    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                                    val timeStr = if (item.attendanceTimestamp != null && item.attendanceTimestamp > 0) {
                                        timeFormat.format(Date(item.attendanceTimestamp))
                                    } else {
                                        "—"
                                    }

                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("report_row_${item.militaryId}"),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(2f)) {
                                                Text(
                                                    text = item.fullName,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "${item.rank} • ${item.unitName ?: "الوحدة العامة"}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Text(
                                                text = item.militaryId,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                color = TacticalGold,
                                                modifier = Modifier.weight(1.2f)
                                            )

                                            // Status Column (✅ حاضر / ❌ لم يحضر / مرض / إجازة)
                                            val isPresent = item.attendanceStatus == AttendanceStatus.PRESENT
                                            val isAbsentOrUnmarked = item.attendanceStatus == AttendanceStatus.ABSENT || item.attendanceStatus == AttendanceStatus.UNMARKED
                                            val statusText = when {
                                                isPresent -> "✅ حاضر"
                                                isAbsentOrUnmarked -> "❌ لم يحضر"
                                                else -> item.attendanceStatus.labelAr
                                            }
                                            val statusColor = when {
                                                isPresent -> StatusPresent
                                                isAbsentOrUnmarked -> StatusAbsent
                                                else -> MaterialTheme.colorScheme.primary
                                            }

                                            Text(
                                                text = statusText,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = statusColor,
                                                modifier = Modifier.weight(1.2f)
                                            )

                                            Text(
                                                text = timeStr,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontFamily = FontFamily.Monospace,
                                                color = if (timeStr != "—") StatusPresent else MaterialTheme.colorScheme.onSurfaceVariant,
                                                textAlign = TextAlign.End,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(icon: String, label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "$icon $value", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = color)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
