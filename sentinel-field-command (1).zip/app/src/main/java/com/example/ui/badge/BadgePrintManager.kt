package com.example.ui.badge

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.print.PrintHelper
import com.example.data.model.SoldierEntity
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.io.OutputStream

/**
 * Off-Screen Military Badge Renderer & Hardware Printing Architecture.
 * Produces CR80 standard PVC card format (85.60 × 53.98 mm) at 300 DPI (1012 × 638 px).
 * Dispatches directly to AndroidX PrintHelper and Scoped Storage MediaStore.
 */
object BadgePrintManager {

    // Standard CR80 PVC dimensions in pixels at 300 DPI
    private const val CARD_WIDTH = 1012
    private const val CARD_HEIGHT = 638

    /**
     * Generates a 512x512 high-contrast QR Code Bitmap from the opaque qrToken.
     * Contains zero plaintext personal/military data.
     */
    fun generateQrCodeBitmap(token: String, size: Int = 512): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H,
            EncodeHintType.MARGIN to 1
        )
        val bitMatrix = QRCodeWriter().encode(token, BarcodeFormat.QR_CODE, size, size, hints)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)

        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        return bitmap
    }

    /**
     * Explicit off-screen renderer drawing the military identity badge onto a native Bitmap.
     */
    fun renderMilitaryBadge(soldier: SoldierEntity, unitName: String): Bitmap {
        val bitmap = Bitmap.createBitmap(CARD_WIDTH, CARD_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // 1. Tactical Background & Border
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#152018")
            style = Paint.Style.FILL
        }
        val cardRect = RectF(0f, 0f, CARD_WIDTH.toFloat(), CARD_HEIGHT.toFloat())
        canvas.drawRoundRect(cardRect, 32f, 32f, bgPaint)

        // Inner Tactical Gold Border
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4AF37")
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        val innerRect = RectF(16f, 16f, CARD_WIDTH - 16f, CARD_HEIGHT - 16f)
        canvas.drawRoundRect(innerRect, 24f, 24f, borderPaint)

        val thinBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#44D4AF37")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawRoundRect(RectF(24f, 24f, CARD_WIDTH - 24f, CARD_HEIGHT - 24f), 20f, 20f, thinBorderPaint)

        // 2. Tactical Header Bar
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1F3024")
            style = Paint.Style.FILL
        }
        val headerRect = RectF(24f, 24f, CARD_WIDTH - 24f, 110f)
        canvas.drawRoundRect(headerRect, 16f, 16f, headerPaint)

        // Header Text
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E5C365")
            textSize = 30f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("ARMED FORCES - MILITARY FIELD IDENTITY CARD", CARD_WIDTH / 2f, 65f, titlePaint)

        val subTitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#A8BBAA")
            textSize = 20f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("بطاقة تحقيق الشخصية العسكرية الميدانية الموحدة", CARD_WIDTH / 2f, 95f, subTitlePaint)

        // 3. Avatar / Photo Placeholder Box (Left Side)
        val photoRect = RectF(50f, 140f, 260f, 400f)
        val photoBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#223326")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(photoRect, 16f, 16f, photoBgPaint)
        val photoBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4AF37")
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(photoRect, 16f, 16f, photoBorder)

        // Tactical Crest / Silhouette inside photo box
        val crestPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4AF37")
            textSize = 48f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("★", photoRect.centerX(), photoRect.centerY() - 10f, crestPaint)
        val crestLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9BB09E")
            textSize = 18f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("OFFICIAL ID", photoRect.centerX(), photoRect.centerY() + 35f, crestLabelPaint)

        // Blood Type Tactical Badge under Photo
        val bloodBadgeRect = RectF(50f, 420f, 260f, 490f)
        val bloodBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8B0000") // Deep Military Crimson
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(bloodBadgeRect, 12f, 12f, bloodBgPaint)
        val bloodTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("فصيلة الدم: ${soldier.bloodType}", bloodBadgeRect.centerX(), bloodBadgeRect.centerY() + 8f, bloodTextPaint)

        // 4. Soldier Data Fields (Center)
        var currentY = 160f
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8E9F90")
            textSize = 19f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F0F5F0")
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val goldValuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E5C365")
            textSize = 30f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        // Military ID
        canvas.drawText("الرقم العسكري (Military ID):", 290f, currentY, labelPaint)
        currentY += 34f
        canvas.drawText(soldier.militaryId, 290f, currentY, goldValuePaint)
        currentY += 45f

        // Full Name
        canvas.drawText("الاسم بالكامل (Full Name):", 290f, currentY, labelPaint)
        currentY += 34f
        canvas.drawText(soldier.fullName, 290f, currentY, valuePaint)
        currentY += 45f

        // Rank
        canvas.drawText("الرتبة العسكرية (Rank):", 290f, currentY, labelPaint)
        currentY += 34f
        canvas.drawText(soldier.rank, 290f, currentY, valuePaint)
        currentY += 45f

        // Unit
        canvas.drawText("الوحدة / الكتيبة (Unit):", 290f, currentY, labelPaint)
        currentY += 34f
        canvas.drawText(unitName, 290f, currentY, valuePaint)
        currentY += 45f

        // Weapon
        canvas.drawText("السلاح المسند (Assigned Weapon):", 290f, currentY, labelPaint)
        currentY += 30f
        val weaponPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#B8C7B9")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(soldier.assignedWeapon, 290f, currentY, weaponPaint)

        // 5. Encrypted Non-Plaintext QR Code (Right Side)
        val qrBitmap = generateQrCodeBitmap(soldier.qrToken, 240)
        val qrX = 720f
        val qrY = 145f

        // White border backing for QR scanner contrast
        val qrBacking = RectF(qrX - 8f, qrY - 8f, qrX + 248f, qrY + 248f)
        val qrBackingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(qrBacking, 12f, 12f, qrBackingPaint)
        canvas.drawBitmap(qrBitmap, qrX, qrY, null)

        val qrSecLabel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#8E9F90")
            textSize = 15f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("CRYPTOGRAPHIC TOKEN", qrX + 120f, qrY + 275f, qrSecLabel)
        canvas.drawText("NO PLAINTEXT LEAKS", qrX + 120f, qrY + 295f, qrSecLabel)

        // 6. Footer / Barcode decoration
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D4AF37")
            textSize = 16f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("AUTHENTICATED FIELD CARD • SECURE OFFLINE TOKEN • NON-TRANSFERABLE", CARD_WIDTH / 2f, CARD_HEIGHT - 35f, footerPaint)

        return bitmap
    }

    /**
     * Physical Badge Printing via AndroidX PrintHelper.
     */
    fun printBadge(context: Context, soldier: SoldierEntity, unitName: String) {
        val badgeBitmap = renderMilitaryBadge(soldier, unitName)
        PrintHelper(context).apply {
            scaleMode = PrintHelper.SCALE_MODE_FIT
        }.printBitmap("MIL_BADGE_${soldier.militaryId}", badgeBitmap)
    }

    /**
     * Saves the high-res badge to Scoped Storage (MediaStore) without legacy permissions.
     */
    fun saveBadgeToStorage(context: Context, soldier: SoldierEntity, unitName: String): Uri? {
        val bitmap = renderMilitaryBadge(soldier, unitName)
        val filename = "MIL_BADGE_${soldier.militaryId}_${System.currentTimeMillis()}.png"

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/MilitaryBadges")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null

        try {
            resolver.openOutputStream(uri)?.use { outputStream: OutputStream ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            return uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            return null
        }
    }
}
