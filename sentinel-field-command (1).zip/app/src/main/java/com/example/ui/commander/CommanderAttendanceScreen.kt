package com.example.ui.commander

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.paging.compose.itemKey
import com.example.data.model.AttendanceStatus
import com.example.data.model.SoldierAttendanceItem
import com.example.data.model.SoldierEntity
import com.example.data.model.UnitEntity
import com.example.security.AuthManager
import com.example.ui.badge.AddSoldierDialog
import com.example.ui.badge.BadgePrintManager
import com.example.ui.components.SoldierItemCard
import com.example.ui.components.TacticalHeader
import com.example.ui.components.TacticalMetricsSummary
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.TacticalCardBorder
import com.example.ui.theme.TacticalGold
import com.example.ui.viewmodel.RollCallViewModel

@Composable
fun CommanderAttendanceScreen(
    authManager: AuthManager,
    viewModel: RollCallViewModel,
    onNavigateToScanner: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToUnitManagement: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val officerName by authManager.officerName.collectAsState()
    val role by authManager.currentRole.collectAsState()

    val selectedDate by viewModel.selectedDate.collectAsState()
    val selectedUnitId by viewModel.selectedUnitId.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val units by viewModel.units.collectAsState()
    val dailySummary by viewModel.dailySummary.collectAsState()
    val exportMsg by viewModel.exportMessage.collectAsState()

    val soldiersPaging = viewModel.soldiersPagingFlow.collectAsLazyPagingItems()

    var showAddSoldierDialog by remember { mutableStateOf(false) }
    var showAddUnitDialog by remember { mutableStateOf(false) }
    var showMarkAllConfirmDialog by remember { mutableStateOf(false) }
    var soldierToTransfer by remember { mutableStateOf<SoldierAttendanceItem?>(null) }

    LaunchedEffect(exportMsg) {
        exportMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearExportMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TacticalHeader(
                title = "غرفة عمليات التمام والضبط الميداني",
                subtitle = "COMMANDER DASHBOARD • ROLL-CALL & RBAC",
                officerName = officerName,
                roleTitle = role?.titleAr ?: "قائد الوحدة",
                onLogout = onLogout,
                extraAction = {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateToUnitManagement,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("open_unit_management_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MilitaryTech,
                                contentDescription = "إدارة التشكيلات والوحدات",
                                tint = TacticalGold
                            )
                        }

                        IconButton(
                            onClick = onNavigateToScanner,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("open_scanner_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "فتح الماسح الضوئي",
                                tint = TacticalGold
                            )
                        }

                        IconButton(
                            onClick = onNavigateToReports,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("open_reports_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assessment,
                                contentDescription = "مركز التقارير",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("open_settings_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("commander_bottom_navigation")
            ) {
                NavigationBarItem(
                    selected = true,
                    onClick = { /* Already on RollCall Dashboard */ },
                    icon = { Icon(Icons.Default.Shield, contentDescription = "التمام الميداني") },
                    label = { Text("التمام", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TacticalGold,
                        selectedTextColor = TacticalGold,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )

                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToUnitManagement,
                    icon = { Icon(Icons.Default.MilitaryTech, contentDescription = "إدارة التشكيلات والوحدات") },
                    label = { Text("الوحدات") }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToScanner,
                    icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = "الماسح الميداني") },
                    label = { Text("الماسح") }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToReports,
                    icon = { Icon(Icons.Default.Assessment, contentDescription = "التقارير") },
                    label = { Text("التقارير") }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = onNavigateToSettings,
                    icon = { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") },
                    label = { Text("الإعدادات") }
                )
            }
        },
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // PDF Export FAB
                FloatingActionButton(
                    onClick = { viewModel.exportDailyPdfReport(context) },
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.testTag("export_pdf_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = "استخراج التقرير العسكري PDF"
                    )
                }

                // Add Unit / Battalion FAB
                FloatingActionButton(
                    onClick = { showAddUnitDialog = true },
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier.testTag("add_unit_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "إضافة كتيبة / سرية جديدة"
                    )
                }

                // Add Soldier & Issue Badge FAB
                FloatingActionButton(
                    onClick = { showAddSoldierDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_soldier_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إصدار بطاقة جديدة"
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tactical Metrics Summary Bar
            TacticalMetricsSummary(summary = dailySummary)

            // Search Bar & Actions Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // FTS Search Field
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = { Text("بحث فوري بالرقم العسكري، الاسم، أو الرتبة...") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "مسح البحث"
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("fts_search_field"),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = TacticalCardBorder
                        )
                    )

                    // Single-Transaction "تحضير الكل كـ حاضر"
                    Button(
                        onClick = { showMarkAllConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusPresent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .height(52.dp)
                            .testTag("mark_all_present_button")
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تحضير الكل")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Unit Filter Chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            border = androidx.compose.foundation.BorderStroke(1.dp, TacticalGold),
                            modifier = Modifier
                                .height(34.dp)
                                .clickable { showAddUnitDialog = true }
                                .testTag("quick_add_unit_chip")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "إضافة كتيبة",
                                    tint = TacticalGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "إضافة كتيبة +",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                    item {
                        UnitFilterChip(
                            label = "كافة الوحدات التكتيكية",
                            isSelected = selectedUnitId == null,
                            onClick = { viewModel.setSelectedUnit(null) }
                        )
                    }
                    items(units, key = { it.unitId }) { unit ->
                        UnitFilterChip(
                            label = unit.unitName,
                            isSelected = selectedUnitId == unit.unitId,
                            onClick = { viewModel.setSelectedUnit(unit.unitId) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Virtualized Paging 3 LazyColumn for 5,000+ Soldiers
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (soldiersPaging.loadState.refresh is LoadState.Loading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                } else if (soldiersPaging.itemCount == 0) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "لا يوجد أفراد مسجلين مطبقين لمعايير البحث",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("soldiers_paging_list"),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(
                            count = soldiersPaging.itemCount,
                            key = soldiersPaging.itemKey { it.militaryId }
                        ) { index ->
                            val soldier = soldiersPaging[index]
                            if (soldier != null) {
                                SoldierItemCard(
                                    soldier = soldier,
                                    canModify = authManager.canPerformManualRollCall(),
                                    onStatusSelected = { newStatus ->
                                        viewModel.updateSoldierStatus(soldier.militaryId, newStatus)
                                    },
                                    onPrintBadge = {
                                        val entity = SoldierEntity(
                                            militaryId = soldier.militaryId,
                                            fullName = soldier.fullName,
                                            rank = soldier.rank,
                                            unitId = soldier.unitId,
                                            bloodType = soldier.bloodType,
                                            assignedWeapon = soldier.assignedWeapon,
                                            qrToken = soldier.qrToken,
                                            isActive = soldier.isActive
                                        )
                                        BadgePrintManager.printBadge(
                                            context = context,
                                            soldier = entity,
                                            unitName = soldier.unitName ?: "الوحدة العسكرية"
                                        )
                                    },
                                    onTransferUnit = {
                                        soldierToTransfer = soldier
                                    }
                                )
                            }
                        }

                        if (soldiersPaging.loadState.append is LoadState.Loading) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Unit Dialog
    if (showAddUnitDialog) {
        AddUnitDialog(
            onDismiss = { showAddUnitDialog = false },
            onSaveUnit = { name, commander, code ->
                viewModel.addUnit(name, commander, code) {
                    showAddUnitDialog = false
                    soldiersPaging.refresh()
                }
            }
        )
    }

    // Transfer Soldier Dialog
    soldierToTransfer?.let { soldier ->
        TransferSoldierDialog(
            soldier = soldier,
            units = units,
            onDismiss = { soldierToTransfer = null },
            onConfirmTransfer = { newUnitId, newUnitName ->
                viewModel.transferSoldier(
                    militaryId = soldier.militaryId,
                    newUnitId = newUnitId,
                    newUnitName = newUnitName
                ) {
                    soldierToTransfer = null
                    soldiersPaging.refresh()
                }
            }
        )
    }

    // Add Soldier Dialog
    if (showAddSoldierDialog) {
        AddSoldierDialog(
            units = units,
            onDismiss = { showAddSoldierDialog = false },
            onSaveAndPrint = { newSoldier, _ ->
                viewModel.addNewSoldier(
                    militaryId = newSoldier.militaryId,
                    fullName = newSoldier.fullName,
                    rank = newSoldier.rank,
                    unitId = newSoldier.unitId,
                    bloodType = newSoldier.bloodType,
                    assignedWeapon = newSoldier.assignedWeapon
                ) {
                    showAddSoldierDialog = false
                    soldiersPaging.refresh()
                }
            }
        )
    }

    // Confirmation Dialog for Bulk Mark All Present
    if (showMarkAllConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showMarkAllConfirmDialog = false },
            title = {
                Text(
                    text = "تأكيد تحضير القوة بالكامل",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "سيتم اعتماد وتسجيل حضور كافة أفراد القوة المسجلة تلقائياً كـ (حاضر) لهذا اليوم بتوقيع القائد في عملية ذرية واحدة (@Transaction). هل تريد المتابعة؟"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.markAllActiveAsPresent()
                        showMarkAllConfirmDialog = false
                        soldiersPaging.refresh()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusPresent),
                    modifier = Modifier.testTag("confirm_mark_all_button")
                ) {
                    Text("اعتماد الحضور للجميع")
                }
            },
            dismissButton = {
                TextButton(onClick = { showMarkAllConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun UnitFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else TacticalCardBorder
        ),
        modifier = Modifier
            .height(34.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
