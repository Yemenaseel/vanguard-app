package com.example.ui.report

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.example.data.model.AttendanceSummary
import com.example.data.model.SoldierAttendanceItem
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Excel-Compatible CSV Roll-Call Exporter.
 * Emits UTF-8 with BOM (\uFEFF) so Microsoft Excel opens Arabic text flawlessly.
 */
object CsvExportManager {

    fun generateAndSaveCsvReport(
        context: Context,
        date: String,
        commanderName: String,
        unitFilterName: String,
        summary: AttendanceSummary,
        records: List<SoldierAttendanceItem>
    ): Uri? {
        val fileName = "Military_RollCall_${date.replace("-", "_")}_${System.currentTimeMillis()}.csv"

        val stringBuilder = StringBuilder()
        // 1. UTF-8 Byte Order Mark (BOM) for Excel
        stringBuilder.append("\uFEFF")

        // 2. Tactical Metadata Header
        stringBuilder.append("\"القيادة العامة للقوات المسلحة - تقرير التمام والجاهزية الميدانية\"\n")
        stringBuilder.append("\"التاريخ:\",\"$date\",\"الوحدة:\",\"$unitFilterName\",\"القائد المشرف:\",\"$commanderName\"\n")
        stringBuilder.append("\"إجمالي القوة:\",\"${summary.totalSoldiers}\",\"حاضر:\",\"${summary.presentCount}\",\"غائب:\",\"${summary.absentCount}\",\"مرض:\",\"${summary.sickCount}\",\"إجازة:\",\"${summary.leaveCount}\",\"مأمورية:\",\"${summary.missionCount}\",\"نسبة الحضور:\",\"${"%.1f".format(summary.presentPercentage)}%\"\n\n")

        // 3. Table Column Headers
        stringBuilder.append("\"م\",\"الرقم العسكري\",\"الرتبة\",\"الاسم بالكامل\",\"الوحدة / الكتيبة\",\"فصيلة الدم\",\"السلاح المسلم\",\"حالة التمام\",\"وقت التحضير\",\"الضابط المسجل\"\n")

        // 4. Data Rows
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        records.forEachIndexed { index, item ->
            val timeStr = if (item.attendanceTimestamp != null && item.attendanceTimestamp > 0) {
                timeFormat.format(Date(item.attendanceTimestamp))
            } else {
                "—"
            }
            val officerStr = item.markedByOfficerName ?: "—"

            stringBuilder.append("\"${index + 1}\",")
            stringBuilder.append("\"${escapeCsv(item.militaryId)}\",")
            stringBuilder.append("\"${escapeCsv(item.rank)}\",")
            stringBuilder.append("\"${escapeCsv(item.fullName)}\",")
            stringBuilder.append("\"${escapeCsv(item.unitName ?: "الوحدة العامة")}\",")
            stringBuilder.append("\"${escapeCsv(item.bloodType)}\",")
            stringBuilder.append("\"${escapeCsv(item.assignedWeapon)}\",")
            stringBuilder.append("\"${escapeCsv(item.attendanceStatus.labelAr)}\",")
            stringBuilder.append("\"$timeStr\",")
            stringBuilder.append("\"${escapeCsv(officerStr)}\"\n")
        }

        val csvBytes = stringBuilder.toString().toByteArray(Charsets.UTF_8)

        return try {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Vanguard_Reports")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
            }

            val resolver = context.contentResolver
            val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Downloads.EXTERNAL_CONTENT_URI
            } else {
                MediaStore.Files.getContentUri("external")
            }

            val uri = resolver.insert(collectionUri, contentValues)
            if (uri != null) {
                val outputStream: OutputStream? = resolver.openOutputStream(uri)
                outputStream?.use { it.write(csvBytes) }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
                Toast.makeText(context, "تم حفظ تقرير Excel (CSV) في مجلد التنزيلات", Toast.LENGTH_LONG).show()
                uri
            } else {
                null
            }
        } catch (e: Exception) {
            Toast.makeText(context, "فشل تصدير ملف Excel: ${e.message}", Toast.LENGTH_SHORT).show()
            null
        }
    }

    private fun escapeCsv(text: String): String {
        return text.replace("\"", "\"\"")
    }
}
