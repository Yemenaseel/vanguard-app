package com.example.ui.settings

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.backup.BackupRestoreManager
import com.example.data.model.OfficerUser
import com.example.data.model.SoldierEntity
import com.example.data.model.UserRole
import com.example.data.repository.RollCallRepository
import com.example.data.settings.AttendanceTimingSettings
import com.example.data.settings.BackupSettings
import com.example.data.settings.CardTemplateSettings
import com.example.data.settings.SettingsDataStore
import com.example.security.AuthManager
import com.example.security.KeyStoreHelper
import com.example.ui.badge.AddSoldierDialog
import com.example.ui.badge.BadgePrintManager
import com.example.ui.commander.AddUserDialog
import com.example.ui.commander.ChangePinDialog
import com.example.ui.commander.EditSoldierDialog
import com.example.ui.components.TacticalHeader
import com.example.ui.theme.StatusAbsent
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.TacticalCardBorder
import com.example.ui.theme.TacticalGold
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    authManager: AuthManager,
    repository: RollCallRepository,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val settingsDataStore = remember { SettingsDataStore(context) }

    val officerName by authManager.officerName.collectAsState()
    val units by repository.getAllUnits().collectAsState(initial = emptyList())
    val allSoldiers by repository.getAllSoldiersIncludingInactive().collectAsState(initial = emptyList())

    // DataStore flows
    val timingSettings by settingsDataStore.attendanceTimingFlow.collectAsState(initial = AttendanceTimingSettings())
    val cardSettings by settingsDataStore.cardTemplateFlow.collectAsState(initial = CardTemplateSettings())
    val backupSettings by settingsDataStore.backupSettingsFlow.collectAsState(initial = BackupSettings())

    // 1. Attendance Timing states (synced with DataStore)
    var startTime by remember { mutableStateOf(timingSettings.startTime) }
    var endTime by remember { mutableStateOf(timingSettings.endTime) }
    var allowRepeatScan by remember { mutableStateOf(timingSettings.allowRepeatScan) }
    var alertOnRepeat by remember { mutableStateOf(timingSettings.alertOnRepeatScan) }
    var defaultUnmarked by remember { mutableStateOf(timingSettings.defaultUnmarkedStatus) }

    LaunchedEffect(timingSettings) {
        startTime = timingSettings.startTime
        endTime = timingSettings.endTime
        allowRepeatScan = timingSettings.allowRepeatScan
        alertOnRepeat = timingSettings.alertOnRepeatScan
        defaultUnmarked = timingSettings.defaultUnmarkedStatus
    }

    // 2. Card Template states (synced with DataStore)
    var badgeOrgName by remember { mutableStateOf(cardSettings.orgName) }
    var showCrest by remember { mutableStateOf(cardSettings.showCrest) }
    var showSoldierName by remember { mutableStateOf(cardSettings.showSoldierName) }
    var showMilitaryId by remember { mutableStateOf(cardSettings.showMilitaryId) }
    var showQrCode by remember { mutableStateOf(cardSettings.showQrCode) }
    var showBlood by remember { mutableStateOf(cardSettings.showBlood) }
    var showWeapon by remember { mutableStateOf(cardSettings.showWeapon) }
    var templateColor by remember { mutableStateOf(cardSettings.templateColor) }

    LaunchedEffect(cardSettings) {
        badgeOrgName = cardSettings.orgName
        showCrest = cardSettings.showCrest
        showSoldierName = cardSettings.showSoldierName
        showMilitaryId = cardSettings.showMilitaryId
        showQrCode = cardSettings.showQrCode
        showBlood = cardSettings.showBlood
        showWeapon = cardSettings.showWeapon
        templateColor = cardSettings.templateColor
    }

    // 3. Backup Settings states (synced with DataStore)
    var backupDestType by remember { mutableStateOf(backupSettings.destinationType) }
    var centralServerUrl by remember { mutableStateOf(backupSettings.centralServerUrl) }

    LaunchedEffect(backupSettings) {
        backupDestType = backupSettings.destinationType
        centralServerUrl = backupSettings.centralServerUrl
    }

    // Personnel search
    var soldierSearchQuery by remember { mutableStateOf("") }

    // Dialog states
    var showAddUserDialog by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAddSoldierDialog by remember { mutableStateOf(false) }
    var soldierToEdit by remember { mutableStateOf<SoldierEntity?>(null) }
    var soldierToDelete by remember { mutableStateOf<SoldierEntity?>(null) }
    var userToDelete by remember { mutableStateOf<OfficerUser?>(null) }
    var isBackingUpDb by remember { mutableStateOf(false) }
    var isRestoringDb by remember { mutableStateOf(false) }

    var usersList by remember { mutableStateOf(authManager.listUsers()) }

    // File pickers for Restore
    val encryptedDbRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isRestoringDb = true
                val result = BackupRestoreManager.importEncryptedDatabaseFromUri(context, uri)
                isRestoringDb = false
                result.onSuccess { msg ->
                    snackbarHostState.showSnackbar(msg)
                    settingsDataStore.recordSuccessfulBackup("Restored: ${uri.lastPathSegment ?: "DB"}")
                }.onFailure { err ->
                    snackbarHostState.showSnackbar(err.message ?: "فشل استيراد قاعدة البيانات")
                }
            }
        }
    }

    val jsonBackupRestoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isRestoringDb = true
                val result = BackupRestoreManager.restoreFromUri(context, uri, repository)
                isRestoringDb = false
                result.onSuccess { count ->
                    snackbarHostState.showSnackbar("✅ تم استيراد وتحديث $count فرد من ملف النسخة الاحتياطية بنجاح.")
                }.onFailure { err ->
                    snackbarHostState.showSnackbar(err.message ?: "فشل استيراد الملف")
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TacticalHeader(
                title = "إعدادات منظومة التمام والضبط",
                subtitle = "TACTICAL SYSTEM CONFIGURATION & DATASTORE",
                officerName = officerName,
                roleTitle = "قائد اللواء",
                onLogout = onNavigateBack,
                extraAction = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = TacticalGold
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ==========================================
            // القسم 1: إعدادات التحضير وتوقيت نافذة الحضور
            // ==========================================
            SettingsSectionCard(
                title = "1. توقيت نافذة التحضير وقواعد التمام",
                icon = Icons.Default.Schedule
            ) {
                Text(
                    text = "تحديد النطاق الزمني لنافذة التحضير وسلوك الرصد (يتم حفظها تلقائياً في DataStore):",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = startTime,
                        onValueChange = {
                            startTime = it
                            authManager.setRollCallStartTime(it)
                            coroutineScope.launch {
                                settingsDataStore.updateAttendanceTiming(
                                    timingSettings.copy(startTime = it)
                                )
                            }
                        },
                        label = { Text("بداية نافذة التحضير") },
                        placeholder = { Text("07:00") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = endTime,
                        onValueChange = {
                            endTime = it
                            authManager.setRollCallEndTime(it)
                            coroutineScope.launch {
                                settingsDataStore.updateAttendanceTiming(
                                    timingSettings.copy(endTime = it)
                                )
                            }
                        },
                        label = { Text("نهاية نافذة التحضير") },
                        placeholder = { Text("08:00") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                SettingToggleRow(
                    title = "هل يسمح بإعادة التحضير؟",
                    description = "تحديث وتأكيد التمام عند مسح نفس البطاقة مجدداً بعد انقضاء التهدئة",
                    checked = allowRepeatScan,
                    onCheckedChange = { checked ->
                        allowRepeatScan = checked
                        authManager.setAllowRepeatScan(checked)
                        coroutineScope.launch {
                            settingsDataStore.updateAttendanceTiming(
                                timingSettings.copy(allowRepeatScan = checked)
                            )
                        }
                    }
                )

                SettingToggleRow(
                    title = "هل يظهر تنبيه عند محاولة تحضير فرد سبق تحضيره؟",
                    description = "إطلاق نغمة واهتزاز تحذيري مع شريط تنبيه فوري عند تكرار المسح",
                    checked = alertOnRepeat,
                    onCheckedChange = { checked ->
                        alertOnRepeat = checked
                        authManager.setAlertOnRepeatScan(checked)
                        coroutineScope.launch {
                            settingsDataStore.updateAttendanceTiming(
                                timingSettings.copy(alertOnRepeatScan = checked)
                            )
                        }
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "تحديد حالة الفرد إذا انتهى وقت التحضير ولم يسجل:",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("ABSENT" to "غائب", "UNMARKED" to "غير مسجل").forEach { (statusKey, label) ->
                            val isSelected = defaultUnmarked == statusKey
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        defaultUnmarked = statusKey
                                        authManager.setDefaultUnmarkedStatus(statusKey)
                                        coroutineScope.launch {
                                            settingsDataStore.updateAttendanceTiming(
                                                timingSettings.copy(defaultUnmarkedStatus = statusKey)
                                            )
                                            snackbarHostState.showSnackbar("تم حفظ الحالة الافتراضية ($label) في DataStore")
                                        }
                                    }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // القسم 2: إدارة المستخدمين (User Management)
            // ==========================================
            SettingsSectionCard(
                title = "2. إدارة المستخدمين والصلاحيات",
                icon = Icons.Default.ManageAccounts
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "المستخدمون والضباط المصرح لهم:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showAddUserDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة مستخدم")
                        }
                        OutlinedButton(
                            onClick = { showChangePinDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تغيير PIN")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                usersList.forEach { user ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (user.role == UserRole.ROLE_ADMIN) TacticalGold.copy(alpha = 0.2f)
                                            else MaterialTheme.colorScheme.primaryContainer
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (user.role == UserRole.ROLE_ADMIN) Icons.Default.Shield else Icons.Default.Security,
                                        contentDescription = null,
                                        tint = if (user.role == UserRole.ROLE_ADMIN) TacticalGold else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = user.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = user.role.titleAr,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (user.role == UserRole.ROLE_ADMIN) TacticalGold else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            if (user.id != "admin_01" && user.id != "recorder_01") {
                                IconButton(
                                    onClick = { userToDelete = user },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف المستخدم",
                                        tint = StatusAbsent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                                ) {
                                    Text(
                                        text = "أساسي",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // =========================================================================
            // القسم 3: النسخ الاحتياطي واستعادة قاعدة البيانات المشفرة (Backup & Restore)
            // =========================================================================
            SettingsSectionCard(
                title = "3. النسخ الاحتياطي واستعادة قاعدة البيانات المشفرة",
                icon = Icons.Default.Backup
            ) {
                Text(
                    text = "تصدير واستيراد قاعدة بيانات Room المشفرة (SQLCipher 256-bit AES) إلى وحدة التخزين الآمنة (Scoped Storage) لضمان أمن وقابلية نقل البيانات التكتيكية:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Encrypted DB Status Banner
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TacticalGold.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = TacticalGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "قاعدة بيانات مشفرة بمفتاح عسكري (256-bit AES)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TacticalGold
                            )
                            val lastBackup = if (backupSettings.lastBackupTimestamp > 0) {
                                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(backupSettings.lastBackupTimestamp))
                            } else "لا يوجد سجل سابق"
                            Text(
                                text = "آخر عملية نسخ: $lastBackup • ${backupSettings.lastBackupFileName.ifEmpty { "جاهز للتصدير" }}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Primary Actions: Encrypted Room DB Export & Import
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Export Encrypted DB Button
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isBackingUpDb = true
                                val (uri, fileName) = BackupRestoreManager.exportEncryptedDatabaseToScopedStorage(context)
                                isBackingUpDb = false
                                if (uri != null && fileName != null) {
                                    settingsDataStore.recordSuccessfulBackup(fileName)
                                    snackbarHostState.showSnackbar("✅ تم تصدير قاعدة البيانات المشفرة (.enc.db) بنجاح إلى المستندات: $fileName")
                                } else {
                                    snackbarHostState.showSnackbar("تعذر تصدير قاعدة البيانات المشفرة")
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        enabled = !isBackingUpDb && !isRestoringDb
                    ) {
                        if (isBackingUpDb) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                        } else {
                            Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير قاعدة البيانات المشفرة", fontSize = 12.sp)
                    }

                    // Import Encrypted DB Button
                    Button(
                        onClick = {
                            encryptedDbRestoreLauncher.launch(arrayOf("*/*"))
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TacticalGold),
                        enabled = !isBackingUpDb && !isRestoringDb
                    ) {
                        if (isRestoringDb) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black)
                        } else {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("استيراد قاعدة البيانات", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Secondary Actions: Structured JSON Export & Import
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                isBackingUpDb = true
                                val (uri, fileName) = BackupRestoreManager.createLocalBackup(context, repository)
                                isBackingUpDb = false
                                if (uri != null && fileName != null) {
                                    snackbarHostState.showSnackbar("✅ تم تصدير نسخة JSON تكتيكية: $fileName")
                                } else {
                                    snackbarHostState.showSnackbar("حدث خطأ أثناء تصدير نسخة JSON")
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isBackingUpDb && !isRestoringDb
                    ) {
                        Icon(imageVector = Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تصدير نسخة JSON", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            jsonBackupRestoreLauncher.launch(arrayOf("*/*"))
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isBackingUpDb && !isRestoringDb
                    ) {
                        Icon(imageVector = Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("استيراد نسخة JSON", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "مكان الحفظ وقاعدة البيانات المركزية:",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("LOCAL" to "مجلد المستندات الآمن (Scoped Storage)", "CENTRAL_SERVER" to "خادم مركزي مشفر").forEach { (typeKey, label) ->
                        val isSelected = backupDestType == typeKey
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    backupDestType = typeKey
                                    authManager.setBackupDestinationType(typeKey)
                                    coroutineScope.launch {
                                        settingsDataStore.updateBackupSettings(
                                            backupSettings.copy(destinationType = typeKey)
                                        )
                                    }
                                }
                        ) {
                            Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (backupDestType == "CENTRAL_SERVER") {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = centralServerUrl,
                        onValueChange = {
                            centralServerUrl = it
                            authManager.setCentralServerUrl(it)
                            coroutineScope.launch {
                                settingsDataStore.updateBackupSettings(
                                    backupSettings.copy(centralServerUrl = it)
                                )
                            }
                        },
                        label = { Text("عنوان خادم المزامنة المركزي (Central Server URL)") },
                        placeholder = { Text("http://192.168.1.100:8080/sync") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // =========================================================================
            // القسم 4: تخصيص قالب البطاقة العسكرية (Custom Card Template Configuration)
            // =========================================================================
            SettingsSectionCard(
                title = "4. تخصيص قالب البطاقة العسكرية",
                icon = Icons.Default.MilitaryTech
            ) {
                Text(
                    text = "تحديد البيانات والعناصر البصرية المطبوعة على بطاقات الهوية الميدانية (محفوظة في DataStore):",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = badgeOrgName,
                    onValueChange = {
                        badgeOrgName = it
                        authManager.setBadgeOrgName(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(
                                cardSettings.copy(orgName = it)
                            )
                        }
                    },
                    label = { Text("اسم القيادة / الجهة العسكرية المطبوع") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Template Color Palette
                Text(
                    text = "نمط ولون قالب البطاقة التكتيكية:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "GOLD" to "ذهبي ملكي",
                        "DESERT" to "صحراوي",
                        "CAMO" to "ميداني تكتيكي",
                        "NAVY" to "عمليات بحرية"
                    ).forEach { (colorKey, colorLabel) ->
                        val isSelected = templateColor == colorKey
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) TacticalGold else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    templateColor = colorKey
                                    coroutineScope.launch {
                                        settingsDataStore.updateCardTemplate(
                                            cardSettings.copy(templateColor = colorKey)
                                        )
                                    }
                                }
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = colorLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Toggles
                SettingToggleRow(
                    title = "شعار النسر والقيادة العامة",
                    description = "طباعة شعار القيادة العسكرية والنسر في أعلى البطاقة",
                    checked = showCrest,
                    onCheckedChange = {
                        showCrest = it
                        authManager.setBadgeShowCrest(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(cardSettings.copy(showCrest = it))
                        }
                    }
                )

                SettingToggleRow(
                    title = "اسم الفرد ورتبته",
                    description = "طباعة الاسم الكامل والرتبة العسكرية بجانب الرمز",
                    checked = showSoldierName,
                    onCheckedChange = {
                        showSoldierName = it
                        authManager.setBadgeShowSoldierName(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(cardSettings.copy(showSoldierName = it))
                        }
                    }
                )

                SettingToggleRow(
                    title = "الرقم العسكري",
                    description = "تضمين الرقم العسكري المعتمد في متن البطاقة",
                    checked = showMilitaryId,
                    onCheckedChange = {
                        showMilitaryId = it
                        authManager.setBadgeShowMilitaryId(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(cardSettings.copy(showMilitaryId = it))
                        }
                    }
                )

                SettingToggleRow(
                    title = "رمز QR الأمني المشفر",
                    description = "طباعة باركود QR بحمولة تشفير HMAC-SHA256 غير قابلة للتزوير",
                    checked = showQrCode,
                    onCheckedChange = {
                        showQrCode = it
                        authManager.setBadgeShowQrCode(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(cardSettings.copy(showQrCode = it))
                        }
                    }
                )

                SettingToggleRow(
                    title = "فصيلة الدم",
                    description = "طباعة فصيلة الدم للطوارئ والعمليات الميدانية",
                    checked = showBlood,
                    onCheckedChange = {
                        showBlood = it
                        authManager.setBadgeShowBlood(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(cardSettings.copy(showBlood = it))
                        }
                    }
                )

                SettingToggleRow(
                    title = "السلاح المخصص",
                    description = "طباعة طراز السلاح والعهدة الشخصية",
                    checked = showWeapon,
                    onCheckedChange = {
                        showWeapon = it
                        authManager.setBadgeShowWeapon(it)
                        coroutineScope.launch {
                            settingsDataStore.updateCardTemplate(cardSettings.copy(showWeapon = it))
                        }
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Live Card Preview
                Text(
                    text = "معاينة حية لقالب البطاقة المخصصة:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                LiveCardPreview(
                    orgName = badgeOrgName,
                    showCrest = showCrest,
                    showSoldierName = showSoldierName,
                    showMilitaryId = showMilitaryId,
                    showQrCode = showQrCode,
                    showBlood = showBlood,
                    showWeapon = showWeapon,
                    templateColor = templateColor
                )
            }

            // ==========================================
            // القسم 5: إدارة الأفراد والبطاقات
            // ==========================================
            SettingsSectionCard(title = "5. إدارة الأفراد والبطاقات", icon = Icons.Default.Badge) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إجمالي الأفراد المسجلين: ${allSoldiers.size} فرد",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = { showAddSoldierDialog = true },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة فرد")
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = soldierSearchQuery,
                    onValueChange = { soldierSearchQuery = it },
                    placeholder = { Text("بحث عن فرد لتعديل بياناته أو إيقافه أو طباعته...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                val filteredSoldiers = remember(allSoldiers, soldierSearchQuery) {
                    if (soldierSearchQuery.isBlank()) allSoldiers.take(6)
                    else allSoldiers.filter {
                        it.fullName.contains(soldierSearchQuery, ignoreCase = true) ||
                                it.militaryId.contains(soldierSearchQuery, ignoreCase = true) ||
                                it.rank.contains(soldierSearchQuery, ignoreCase = true)
                    }
                }

                filteredSoldiers.forEach { soldier ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${soldier.rank} / ${soldier.fullName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${soldier.militaryId} • ${if (soldier.isActive) "✅ نشط بالخدمة" else "⛔ موقوف عن التمام"}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (soldier.isActive) StatusPresent else StatusAbsent
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(onClick = { soldierToEdit = soldier }, modifier = Modifier.size(32.dp)) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل بيانات فرد", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                }

                                IconButton(
                                    onClick = {
                                        coroutineScope.launch {
                                            val newStatus = !soldier.isActive
                                            repository.setSoldierActiveStatus(soldier.militaryId, newStatus)
                                            snackbarHostState.showSnackbar(
                                                if (newStatus) "تم تفعيل الفرد وإعادته للتمام" else "تم إيقاف الفرد عن التمام"
                                            )
                                        }
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (soldier.isActive) Icons.Default.Block else Icons.Default.CheckCircle,
                                        contentDescription = "إيقاف/تفعيل فرد",
                                        modifier = Modifier.size(16.dp),
                                        tint = if (soldier.isActive) StatusAbsent else StatusPresent
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val unitName = units.find { it.unitId == soldier.unitId }?.unitName ?: "الوحدة العامة"
                                        BadgePrintManager.printBadge(context, soldier, unitName)
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Print, contentDescription = "طباعة البطاقات", modifier = Modifier.size(16.dp))
                                }

                                IconButton(
                                    onClick = { soldierToDelete = soldier },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف الفرد نهائياً", modifier = Modifier.size(16.dp), tint = StatusAbsent)
                                }
                            }
                        }
                    }
                }
            }

            // ==========================================
            // القسم 6: معلومات البرنامج
            // ==========================================
            SettingsSectionCard(title = "6. معلومات المنظومة", icon = Icons.Default.Info) {
                InfoRow(label = "اسم البرنامج:", value = "منظومة التمام والضبط العسكري (Vanguard Tactical)")
                InfoRow(label = "الإصدار:", value = "v2.6.0 Tactical Enterprise")
                InfoRow(label = "إدارة التفضيلات:", value = "Jetpack DataStore Preferences & Room Transactions")
                InfoRow(label = "تشفير البيانات:", value = "SQLCipher 256-bit AES • Scoped Storage MediaStore")
            }
        }
    }

    // Dialogs
    if (showAddUserDialog) {
        AddUserDialog(
            onDismiss = { showAddUserDialog = false },
            onAddUser = { name, role, pin ->
                authManager.addUser(name, pin, role)
                usersList = authManager.listUsers()
                showAddUserDialog = false
                coroutineScope.launch {
                    settingsDataStore.saveUsersList(usersList)
                    snackbarHostState.showSnackbar("تمت إضافة المستخدم بنجاح وحفظه في DataStore")
                }
            }
        )
    }

    if (showChangePinDialog) {
        ChangePinDialog(
            isAdmin = true,
            onDismiss = { showChangePinDialog = false },
            onChangePin = { oldPin, newPin ->
                val success = authManager.changeAdminPin(oldPin, newPin)
                if (success) {
                    showChangePinDialog = false
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("تم تغيير رمز الدخول (PIN) بنجاح")
                    }
                } else {
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("رمز PIN القديم غير صحيح")
                    }
                }
            }
        )
    }

    if (showAddSoldierDialog) {
        AddSoldierDialog(
            units = units,
            onDismiss = { showAddSoldierDialog = false },
            onSaveAndPrint = { newSoldier, _ ->
                coroutineScope.launch {
                    repository.addSoldier(newSoldier)
                    showAddSoldierDialog = false
                    snackbarHostState.showSnackbar("تمت إضافة الفرد بنجاح")
                }
            }
        )
    }

    soldierToEdit?.let { soldier ->
        EditSoldierDialog(
            soldier = soldier,
            units = units,
            onDismiss = { soldierToEdit = null },
            onSave = { updatedSoldier ->
                coroutineScope.launch {
                    repository.updateSoldier(updatedSoldier)
                    soldierToEdit = null
                    snackbarHostState.showSnackbar("تم تعديل بيانات الفرد بنجاح")
                }
            }
        )
    }

    soldierToDelete?.let { soldier ->
        AlertDialog(
            onDismissRequest = { soldierToDelete = null },
            title = { Text("تأكيد حذف الفرد نهائياً", fontWeight = FontWeight.Bold, color = StatusAbsent) },
            text = { Text("هل أنت متأكد من رغبتك في حذف الفرد \"${soldier.fullName}\" صاحب الرقم العسكري (${soldier.militaryId}) من قاعدة البيانات؟ لا يمكن التراجع عن هذا الإجراء.") },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            repository.deleteSoldier(soldier)
                            soldierToDelete = null
                            snackbarHostState.showSnackbar("تم حذف الفرد من قاعدة البيانات")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAbsent)
                ) {
                    Text("حذف نهائي")
                }
            },
            dismissButton = {
                TextButton(onClick = { soldierToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    userToDelete?.let { user ->
        AlertDialog(
            onDismissRequest = { userToDelete = null },
            title = { Text("تأكيد حذف المستخدم", fontWeight = FontWeight.Bold, color = StatusAbsent) },
            text = { Text("هل أنت متأكد من رغبتك في حذف المستخدم \"${user.name}\" وإلغاء صلاحياته؟") },
            confirmButton = {
                Button(
                    onClick = {
                        authManager.deleteUser(user.id)
                        usersList = authManager.listUsers()
                        userToDelete = null
                        coroutineScope.launch {
                            settingsDataStore.saveUsersList(usersList)
                            snackbarHostState.showSnackbar("تم حذف المستخدم وتحديث DataStore")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAbsent)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                TextButton(onClick = { userToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun LiveCardPreview(
    orgName: String,
    showCrest: Boolean,
    showSoldierName: Boolean,
    showMilitaryId: Boolean,
    showQrCode: Boolean,
    showBlood: Boolean,
    showWeapon: Boolean,
    templateColor: String
) {
    val borderColor = when (templateColor) {
        "GOLD" -> TacticalGold
        "DESERT" -> Color(0xFFD4A373)
        "CAMO" -> Color(0xFF588157)
        "NAVY" -> Color(0xFF3A86FF)
        else -> TacticalGold
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header: Org Name & Crest
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showCrest) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = borderColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = orgName,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = borderColor
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(borderColor.copy(alpha = 0.3f))
            )

            // Content
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (showSoldierName) {
                        Text(
                            text = "رقيب أول / محمد أحمد الشريف",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (showMilitaryId) {
                        Text(
                            text = "الرقم العسكري: MIL-10042",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (showBlood) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StatusAbsent.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "فصيلة الدم: O+",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusAbsent,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        if (showWeapon) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = "M4A1 Carbine",
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                if (showQrCode) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(46.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = TacticalGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = TacticalGold,
                checkedTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
