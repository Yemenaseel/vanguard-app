package com.example.ui.scanner

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.SoldierEntity
import com.example.data.model.UserRole
import com.example.security.AuthManager
import com.example.ui.components.TacticalHeader
import com.example.ui.theme.StatusPresent
import com.example.ui.theme.TacticalCardBorder
import com.example.ui.theme.TacticalGold
import java.util.concurrent.Executors

@OptIn(ExperimentalGetImage::class)
@Composable
fun ScannerScreen(
    authManager: AuthManager,
    scannerViewModel: ScannerViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToReports: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val officerName by authManager.officerName.collectAsState()
    val role by authManager.currentRole.collectAsState()

    val lastScanned by scannerViewModel.lastScannedSoldier.collectAsState()
    val alertMessage by scannerViewModel.scanAlertMessage.collectAsState()
    val isProcessing by scannerViewModel.isProcessingScan.collectAsState()
    val isTorchEnabled by scannerViewModel.isTorchEnabled.collectAsState()
    val sessionCount by scannerViewModel.sessionScanCount.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Vibrator & Tone Generator for Hardware Haptic & Audio Feedback
    val vibrator = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    val toneGenerator = remember {
        try {
            ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
        } catch (e: Exception) {
            null
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                toneGenerator?.release()
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    fun triggerSuccessFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(120)
            }
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (e: Exception) {
            // Audio/Haptic fallback
        }
    }

    fun triggerFailureFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 80, 80), -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(200)
            }
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 250)
        } catch (e: Exception) {
            // Audio/Haptic fallback
        }
    }

    // Collect feedback events from ScannerViewModel
    LaunchedEffect(scannerViewModel) {
        scannerViewModel.feedbackEvents.collect { event ->
            when (event) {
                is ScanFeedbackEvent.Success -> triggerSuccessFeedback()
                is ScanFeedbackEvent.Failure -> triggerFailureFeedback()
            }
        }
    }

    var manualTokenText by remember { mutableStateOf("") }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Tactical Header Bar
            TacticalHeader(
                title = "محطة الرصد والتحضير السريع",
                subtitle = "FIELD ROLL-CALL SCANNER HUD",
                officerName = officerName,
                roleTitle = role?.titleAr ?: "ضابط رصد",
                onLogout = onNavigateBack,
                extraAction = {
                    if (role == UserRole.ROLE_ADMIN) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "العودة للوحة القيادة",
                                tint = TacticalGold
                            )
                        }
                    }
                }
            )

            // Camera Viewport Box with HUD
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (hasCameraPermission) {
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx)
                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)

                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.surfaceProvider = previewView.surfaceProvider
                                }

                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()

                                val cameraExecutor = Executors.newSingleThreadExecutor()
                                val analyzer = scannerViewModel.createImageAnalyzer()
                                imageAnalysis.setAnalyzer(cameraExecutor, analyzer)

                                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                                try {
                                    cameraProvider.unbindAll()
                                    val camera = cameraProvider.bindToLifecycle(
                                        lifecycleOwner,
                                        cameraSelector,
                                        preview,
                                        imageAnalysis
                                    )
                                    scannerViewModel.setCameraControl(camera.cameraControl)
                                } catch (e: Exception) {
                                    // Camera bind exception
                                }
                            }, ContextCompat.getMainExecutor(ctx))

                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "يلزم إذن الكاميرا لمسح بطاقات الهوية الميدانية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("منح إذن الكاميرا")
                        }
                    }
                }

                // Tactical Reticle HUD Overlay
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val boxSize = (w.coerceAtMost(h) * 0.65f)
                    val left = (w - boxSize) / 2f
                    val top = (h - boxSize) / 2f
                    val right = left + boxSize
                    val bottom = top + boxSize
                    val cornerLen = 36.dp.toPx()
                    val strokeW = 4.dp.toPx()
                    val hudColor = Color(0xFFD4AF37)

                    // Corner Brackets
                    // Top-Left
                    drawLine(hudColor, Offset(left, top), Offset(left + cornerLen, top), strokeW)
                    drawLine(hudColor, Offset(left, top), Offset(left, top + cornerLen), strokeW)

                    // Top-Right
                    drawLine(hudColor, Offset(right, top), Offset(right - cornerLen, top), strokeW)
                    drawLine(hudColor, Offset(right, top), Offset(right, top + cornerLen), strokeW)

                    // Bottom-Left
                    drawLine(hudColor, Offset(left, bottom), Offset(left + cornerLen, bottom), strokeW)
                    drawLine(hudColor, Offset(left, bottom), Offset(left, bottom - cornerLen), strokeW)

                    // Bottom-Right
                    drawLine(hudColor, Offset(right, bottom), Offset(right - cornerLen, bottom), strokeW)
                    drawLine(hudColor, Offset(right, bottom), Offset(right, bottom - cornerLen), strokeW)

                    // Center Crosshair
                    val cx = w / 2f
                    val cy = h / 2f
                    val crossLen = 12.dp.toPx()
                    drawLine(Color(0x80D4AF37), Offset(cx - crossLen, cy), Offset(cx + crossLen, cy), 2.dp.toPx())
                    drawLine(Color(0x80D4AF37), Offset(cx, cy - crossLen), Offset(cx, cy + crossLen), 2.dp.toPx())
                }

                // Top Floating Tactical Toolbar (Session Count + Torch Toggle)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Session Count Badge
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.Black.copy(alpha = 0.65f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(StatusPresent)
                            )
                            Text(
                                text = "التمام المسجل: $sessionCount",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Reports / Results Button for Supervisor / Field Officer
                    if (onNavigateToReports != null) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.Black.copy(alpha = 0.75f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, TacticalGold),
                            modifier = Modifier.clickable { onNavigateToReports() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TableChart,
                                    contentDescription = "النتائج والتقارير",
                                    tint = TacticalGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "مراجعة النتائج",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    // Torch Hardware Toggle
                    IconButton(
                        onClick = { scannerViewModel.toggleTorch() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(if (isTorchEnabled) TacticalGold else Color.Black.copy(alpha = 0.65f))
                            .border(1.dp, TacticalGold, CircleShape)
                            .testTag("torch_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "إضاءة الفلاش",
                            tint = if (isTorchEnabled) Color.Black else Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Processing Indicator
                if (isProcessing) {
                    CircularProgressIndicator(
                        color = TacticalGold,
                        modifier = Modifier
                            .size(36.dp)
                            .align(Alignment.Center)
                    )
                }

                // On-Screen Instant Confirmation Card Banner
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                ) {
                    AnimatedVisibility(
                        visible = lastScanned != null,
                        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
                    ) {
                        lastScanned?.let { soldier ->
                            SoldierScanSuccessBanner(
                                soldier = soldier,
                                onDismiss = { scannerViewModel.clearLastScanned() }
                            )
                        }
                    }
                }
            }

            // Bottom Tactical Simulation and Diagnostics Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "محاكي المسح السريع الميداني (Operational Test Token):",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = manualTokenText,
                            onValueChange = { manualTokenText = it },
                            placeholder = { Text("أدخل رمز البطاقة المشفر...") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("manual_token_input"),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = TacticalCardBorder
                            )
                        )

                        Button(
                            onClick = {
                                if (manualTokenText.isNotBlank()) {
                                    scannerViewModel.processScannedBarcode(manualTokenText)
                                }
                            },
                            modifier = Modifier
                                .height(50.dp)
                                .testTag("simulate_scan_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("مسح")
                        }
                    }

                    // Quick-Test Tokens Chips
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuickDemoTokenChip(
                            label = "رقيب أول: محمد أحمد",
                            token = "MIL-DEMO-TOKEN-ALPHA-01",
                            onClick = {
                                manualTokenText = "MIL-DEMO-TOKEN-ALPHA-01"
                                scannerViewModel.processScannedBarcode("MIL-DEMO-TOKEN-ALPHA-01")
                            }
                        )
                        QuickDemoTokenChip(
                            label = "ملازم أول: عمر طارق",
                            token = "MIL-DEMO-TOKEN-BRAVO-02",
                            onClick = {
                                manualTokenText = "MIL-DEMO-TOKEN-BRAVO-02"
                                scannerViewModel.processScannedBarcode("MIL-DEMO-TOKEN-BRAVO-02")
                            }
                        )
                        QuickDemoTokenChip(
                            label = "بطاقة غير مسجلة (اختبار)",
                            token = "INVALID-ENEMY-TOKEN",
                            onClick = {
                                manualTokenText = "INVALID-ENEMY-TOKEN"
                                scannerViewModel.processScannedBarcode("INVALID-ENEMY-TOKEN")
                            }
                        )
                    }
                }
            }
        }
    }

    // Invalid Card Alert Dialog
    if (alertMessage != null) {
        AlertDialog(
            onDismissRequest = { scannerViewModel.clearScanAlert() },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = "تنبيه أمني ميداني",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            text = {
                Text(
                    text = alertMessage ?: "بطاقة غير مصرح بها أو غير مسجلة",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = { scannerViewModel.clearScanAlert() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("dismiss_alert_button")
                ) {
                    Text("إغلاق التنبيه")
                }
            }
        )
    }
}

@Composable
private fun QuickDemoTokenChip(
    label: String,
    token: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, TacticalCardBorder),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun SoldierScanSuccessBanner(
    soldier: SoldierEntity,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("scan_success_banner"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(2.dp, StatusPresent),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(StatusPresent.copy(alpha = 0.15f))
                        .border(1.5.dp, StatusPresent, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = StatusPresent,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = soldier.rank,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = StatusPresent
                        )
                        Text(
                            text = soldier.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = "الرقم العسكري: ${soldier.militaryId} • فصيلة: ${soldier.bloodType}",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Text(
                        text = "تم تسجيل الحضور بنجاح في قاعدة البيانات المشفرة",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusPresent,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "تم",
                    tint = StatusPresent
                )
            }
        }
    }
}
