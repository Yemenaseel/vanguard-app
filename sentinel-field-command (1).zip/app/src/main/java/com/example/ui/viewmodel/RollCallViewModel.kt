package com.example.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSummary
import com.example.data.model.SoldierAttendanceItem
import com.example.data.model.SoldierEntity
import com.example.data.model.UnitEntity
import com.example.data.repository.RollCallRepository
import com.example.security.AuthManager
import com.example.security.KeyStoreHelper
import com.example.ui.badge.BadgePrintManager
import com.example.ui.report.PdfExportManager
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class RollCallViewModel(
    private val repository: RollCallRepository,
    private val authManager: AuthManager
) : ViewModel() {

    val currentDate = repository.getTodayDateString()

    private val _selectedDate = MutableStateFlow(currentDate)
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _selectedUnitId = MutableStateFlow<Long?>(null)
    val selectedUnitId: StateFlow<Long?> = _selectedUnitId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val units: StateFlow<List<UnitEntity>> = repository.getAllUnits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailySummary: StateFlow<AttendanceSummary> = _selectedDate
        .flatMapLatest { date -> repository.getDailyAttendanceSummary(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AttendanceSummary())

    // Virtualized Paging 3 stream reacting to Date, Unit Filter, and FTS Search
    val soldiersPagingFlow: Flow<PagingData<SoldierAttendanceItem>> = combine(
        _selectedDate,
        _selectedUnitId,
        _searchQuery
    ) { date, unitId, query ->
        Triple(date, unitId, query)
    }.flatMapLatest { (date, unitId, query) ->
        repository.getSoldiersPagingFlow(date, unitId, query)
    }.cachedIn(viewModelScope)

    // Scanner Feedback States
    private val _lastScannedSoldier = MutableStateFlow<SoldierEntity?>(null)
    val lastScannedSoldier: StateFlow<SoldierEntity?> = _lastScannedSoldier.asStateFlow()

    private val _scanAlertMessage = MutableStateFlow<String?>(null)
    val scanAlertMessage: StateFlow<String?> = _scanAlertMessage.asStateFlow()

    private val _isProcessingScan = MutableStateFlow(false)
    val isProcessingScan: StateFlow<Boolean> = _isProcessingScan.asStateFlow()

    private val _exportMessage = MutableStateFlow<String?>(null)
    val exportMessage: StateFlow<String?> = _exportMessage.asStateFlow()

    // 3-second throttle cache: token -> timestamp
    private val throttleMap = mutableMapOf<String, Long>()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedUnit(unitId: Long?) {
        _selectedUnitId.value = unitId
    }

    fun setSelectedDate(date: String) {
        _selectedDate.value = date
    }

    /**
     * Resolves scanned QR token with 3-second debounce throttle.
     * Returns true if registered successfully, false otherwise.
     */
    fun processScannedToken(token: String, onComplete: (Boolean, SoldierEntity?, String?) -> Unit) {
        val now = System.currentTimeMillis()
        val lastSeen = throttleMap[token] ?: 0L

        // Throttle 3 seconds
        if (now - lastSeen < 3000L) {
            return
        }
        throttleMap[token] = now

        viewModelScope.launch {
            _isProcessingScan.value = true
            val role = authManager.currentRole.value?.name ?: "ROLE_RECORDER"
            val officerName = authManager.officerName.value

            val result = repository.recordQrScanAttendance(token, officerName, role)
            result.onSuccess { soldier ->
                _lastScannedSoldier.value = soldier
                _scanAlertMessage.value = null
                onComplete(true, soldier, null)
            }.onFailure { exception ->
                val errorMsg = exception.message ?: "بطاقة غير مصرح بها أو غير مسجلة"
                _lastScannedSoldier.value = null
                _scanAlertMessage.value = errorMsg
                onComplete(false, null, errorMsg)
            }
            _isProcessingScan.value = false
        }
    }

    fun clearScanAlert() {
        _scanAlertMessage.value = null
    }

    fun clearLastScanned() {
        _lastScannedSoldier.value = null
    }

    /**
     * Manual status update (ROLE_ADMIN only)
     */
    fun updateSoldierStatus(militaryId: String, status: AttendanceStatus) {
        if (!authManager.canPerformManualRollCall()) return

        viewModelScope.launch {
            val role = authManager.currentRole.value?.name ?: "ROLE_ADMIN"
            val officerName = authManager.officerName.value
            repository.updateAttendanceStatus(
                militaryId = militaryId,
                date = _selectedDate.value,
                status = status,
                officerName = officerName,
                role = role
            )
        }
    }

    /**
     * Single-transaction bulk action: Mark all active soldiers as PRESENT.
     */
    fun markAllActiveAsPresent() {
        if (!authManager.canPerformManualRollCall()) return

        viewModelScope.launch {
            val role = authManager.currentRole.value?.name ?: "ROLE_ADMIN"
            val officerName = authManager.officerName.value
            repository.markAllActiveAsPresent(
                date = _selectedDate.value,
                officerName = officerName,
                role = role
            )
        }
    }

    /**
     * Issues new military identity with unguessable cryptographic token.
     */
    fun addNewSoldier(
        militaryId: String,
        fullName: String,
        rank: String,
        unitId: Long,
        bloodType: String,
        assignedWeapon: String,
        onSuccess: (SoldierEntity) -> Unit
    ) {
        if (!authManager.canAddOrEditSoldier()) return

        viewModelScope.launch {
            val secureToken = KeyStoreHelper.generateSecureQrToken()
            val newSoldier = SoldierEntity(
                militaryId = militaryId.trim(),
                fullName = fullName.trim(),
                rank = rank.trim(),
                unitId = unitId,
                bloodType = bloodType.trim(),
                assignedWeapon = assignedWeapon.trim(),
                qrToken = secureToken,
                isActive = true
            )
            repository.addSoldier(newSoldier)
            onSuccess(newSoldier)
        }
    }

    /**
     * Creates and adds a new military unit / battalion (Commander only).
     */
    fun addUnit(
        unitName: String,
        commanderName: String,
        codeSymbol: String,
        onSuccess: () -> Unit
    ) {
        if (!authManager.canAddOrEditSoldier()) return

        viewModelScope.launch {
            repository.addUnit(unitName, commanderName, codeSymbol)
            _exportMessage.value = "تمت إضافة الكتيبة / الوحدة ($unitName) بنجاح"
            onSuccess()
        }
    }

    /**
     * Transfers a soldier from one battalion/unit to another (Commander only).
     */
    fun transferSoldier(
        militaryId: String,
        newUnitId: Long,
        newUnitName: String,
        onSuccess: () -> Unit
    ) {
        if (!authManager.canPerformManualRollCall()) return

        viewModelScope.launch {
            val success = repository.transferSoldierToUnit(militaryId, newUnitId)
            if (success) {
                _exportMessage.value = "تم نقل الفرد بنجاح إلى: $newUnitName"
                onSuccess()
            }
        }
    }

    /**
     * Physical Badge Printing
     */
    fun printBadge(context: Context, soldier: SoldierEntity, unitName: String) {
        BadgePrintManager.printBadge(context, soldier, unitName)
    }

    /**
     * Save badge image to gallery / Scoped Storage
     */
    fun saveBadgeToStorage(context: Context, soldier: SoldierEntity, unitName: String): Uri? {
        return BadgePrintManager.saveBadgeToStorage(context, soldier, unitName)
    }

    /**
     * Generates and exports official signed PDF report
     */
    fun exportDailyPdfReport(context: Context) {
        if (!authManager.canExportPdfReports()) return

        viewModelScope.launch {
            val date = _selectedDate.value
            val unitId = _selectedUnitId.value
            val unitName = if (unitId != null) {
                units.value.find { it.unitId == unitId }?.unitName ?: "وحدة محددة"
            } else {
                "كافة الوحدات التكتيكية (All Units)"
            }
            val summary = dailySummary.value
            val records = repository.getAllSoldiersForReport(date, unitId)

            val uri = PdfExportManager.generateAndSaveDailyReport(
                context = context,
                date = date,
                commanderName = authManager.officerName.value,
                unitFilterName = unitName,
                summary = summary,
                records = records
            )
            if (uri != null) {
                _exportMessage.value = "تم استخراج التقرير العسكري بنجاح"
            }
        }
    }

    fun clearExportMessage() {
        _exportMessage.value = null
    }

    class Factory(
        private val repository: RollCallRepository,
        private val authManager: AuthManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return RollCallViewModel(repository, authManager) as T
        }
    }
}
