package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Military Palette
val TacticalDarkBackground = Color(0xFF0F1511)
val TacticalDarkSurface = Color(0xFF162018)
val TacticalDarkSurfaceVariant = Color(0xFF1F2C22)
val TacticalCardBorder = Color(0xFF2C3E30)

val TacticalPrimary = Color(0xFF4C8055)
val TacticalPrimaryContainer = Color(0xFF1E3823)
val TacticalOnPrimary = Color(0xFFFFFFFF)
val TacticalOnPrimaryContainer = Color(0xFFA5D6A7)

val TacticalGold = Color(0xFFD4AF37)
val TacticalGoldContainer = Color(0xFF382F10)
val TacticalOnGoldContainer = Color(0xFFFFE082)

val TacticalSecondary = Color(0xFF819785)
val TacticalSecondaryContainer = Color(0xFF28362B)

val TacticalError = Color(0xFFEF5350)
val TacticalOnError = Color(0xFFFFFFFF)

// Roll-Call Status Colors
val StatusPresent = Color(0xFF2E7D32)
val StatusAbsent = Color(0xFFD32F2F)
val StatusSick = Color(0xFFF57C00)
val StatusLeave = Color(0xFF1976D2)
val StatusMission = Color(0xFF7B1FA2)
val StatusUnmarked = Color(0xFF607D8B)

