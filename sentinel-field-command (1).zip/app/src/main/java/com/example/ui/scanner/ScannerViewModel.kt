package com.example.ui.scanner

import androidx.annotation.OptIn
import androidx.camera.core.CameraControl
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.SoldierEntity
import com.example.data.repository.RollCallRepository
import com.example.security.AuthManager
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Sealed class representing real-time scan feedback events for audio and haptic drivers.
 */
sealed class ScanFeedbackEvent {
    data class Success(val soldier: SoldierEntity) : ScanFeedbackEvent()
    data class Failure(val errorMessage: String, val token: String) : ScanFeedbackEvent()
}

/**
 * ScannerViewModel: Integrates CameraX and ML Kit for continuous offline barcode scanning.
 * Implements 3-second debounce/throttling, cryptographic validation, and secure lookup flow
 * against the encrypted Room/SQLCipher database.
 */
class ScannerViewModel(
    private val repository: RollCallRepository,
    private val authManager: AuthManager
) : ViewModel() {

    companion object {
        const val DEBOUNCE_INTERVAL_MS = 3000L
    }

    // CameraX Background Analyzer Executor
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    // ML Kit Barcode Scanner configured strictly for QR Codes (lazily initialized)
    private var barcodeScannerInstance: BarcodeScanner? = null

    private fun getBarcodeScanner(): BarcodeScanner {
        return barcodeScannerInstance ?: BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                .build()
        ).also { barcodeScannerInstance = it }
    }

    // Camera hardware control (Torch / Focus)
    private var cameraControl: CameraControl? = null

    // UI States
    private val _lastScannedSoldier = MutableStateFlow<SoldierEntity?>(null)
    val lastScannedSoldier: StateFlow<SoldierEntity?> = _lastScannedSoldier.asStateFlow()

    private val _scanAlertMessage = MutableStateFlow<String?>(null)
    val scanAlertMessage: StateFlow<String?> = _scanAlertMessage.asStateFlow()

    private val _isProcessingScan = MutableStateFlow(false)
    val isProcessingScan: StateFlow<Boolean> = _isProcessingScan.asStateFlow()

    private val _isTorchEnabled = MutableStateFlow(false)
    val isTorchEnabled: StateFlow<Boolean> = _isTorchEnabled.asStateFlow()

    private val _sessionScanCount = MutableStateFlow(0)
    val sessionScanCount: StateFlow<Int> = _sessionScanCount.asStateFlow()

    private val _recentScannedList = MutableStateFlow<List<SoldierEntity>>(emptyList())
    val recentScannedList: StateFlow<List<SoldierEntity>> = _recentScannedList.asStateFlow()

    // Feedback Event bus for Haptics & Audio Chimes
    private val _feedbackEvents = MutableSharedFlow<ScanFeedbackEvent>(extraBufferCapacity = 16)
    val feedbackEvents: SharedFlow<ScanFeedbackEvent> = _feedbackEvents.asSharedFlow()

    // Thread-safe debounce cache: token -> last processed timestamp
    private val throttleMap = ConcurrentHashMap<String, Long>()

    // In-flight token lock set to prevent concurrent duplicate processing of adjacent frames
    private val inFlightTokens = ConcurrentHashMap.newKeySet<String>()

    /**
     * Binds CameraControl reference from CameraX Preview lifecycle for torch and focus manipulation.
     */
    fun setCameraControl(control: CameraControl?) {
        this.cameraControl = control
        control?.enableTorch(_isTorchEnabled.value)
    }

    /**
     * Toggles Camera Flash / Torch hardware state.
     */
    fun toggleTorch() {
        val nextState = !_isTorchEnabled.value
        _isTorchEnabled.value = nextState
        cameraControl?.enableTorch(nextState)
    }

    /**
     * Creates a high-performance ImageAnalysis.Analyzer wired directly to ML Kit.
     * Continuously analyzes CameraX frames on a background thread and delegates
     * decoded barcodes to the secure lookup flow.
     */
    @OptIn(ExperimentalGetImage::class)
    fun createImageAnalyzer(): ImageAnalysis.Analyzer {
        return ImageAnalysis.Analyzer { imageProxy: ImageProxy ->
            val mediaImage = imageProxy.image
            if (mediaImage == null) {
                imageProxy.close()
                return@Analyzer
            }

            val inputImage = InputImage.fromMediaImage(
                mediaImage,
                imageProxy.imageInfo.rotationDegrees
            )

            getBarcodeScanner().process(inputImage)
                .addOnSuccessListener { barcodes ->
                    for (barcode in barcodes) {
                        val rawValue = barcode.rawValue
                        if (!rawValue.isNullOrBlank()) {
                            processScannedBarcode(rawValue)
                        }
                    }
                }
                .addOnFailureListener {
                    // Frame analysis failed, continue stream
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        }
    }

    /**
     * Continuous Barcode Processor with Debounce Logic & Secure Lookup Flow.
     * 1. Debounce check: Ignores repeat scans of the same token within 3000ms.
     * 2. In-flight check: Discards simultaneous frame detections of the same token.
     * 3. Database lookup: Queries the encrypted SQLCipher Room database for the non-sensitive token.
     * 4. Atomic record: If found, marks the soldier as PRESENT for today's roll-call.
     * 5. Feedback emission: Dispatches Success/Failure for haptics, audio, and HUD display.
     */
    fun processScannedBarcode(rawToken: String, onComplete: ((Boolean, SoldierEntity?, String?) -> Unit)? = null) {
        val trimmedToken = rawToken.trim()
        if (trimmedToken.isEmpty()) return

        val now = System.currentTimeMillis()
        val lastProcessedTime = throttleMap[trimmedToken] ?: 0L

        // 3-second debounce throttle
        if (now - lastProcessedTime < DEBOUNCE_INTERVAL_MS) {
            return
        }

        // Prevent duplicate concurrent requests for the same token
        if (!inFlightTokens.add(trimmedToken)) {
            return
        }

        throttleMap[trimmedToken] = now

        viewModelScope.launch {
            _isProcessingScan.value = true
            try {
                val role = authManager.currentRole.value?.name ?: "ROLE_RECORDER"
                val officerName = authManager.officerName.value

                // Secure Lookup Flow against encrypted database
                val result = repository.recordQrScanAttendance(trimmedToken, officerName, role)

                result.onSuccess { soldier ->
                    _lastScannedSoldier.value = soldier
                    _scanAlertMessage.value = null
                    _sessionScanCount.value += 1

                    // Update recent scans list (keep last 10 entries)
                    val updatedList = (listOf(soldier) + _recentScannedList.value.filter { it.militaryId != soldier.militaryId })
                        .take(10)
                    _recentScannedList.value = updatedList

                    _feedbackEvents.emit(ScanFeedbackEvent.Success(soldier))
                    onComplete?.invoke(true, soldier, null)
                }.onFailure { exception ->
                    val errorMsg = exception.message ?: "بطاقة غير مصرح بها أو غير مسجلة في قاعدة البيانات العسكرية"
                    _lastScannedSoldier.value = null
                    _scanAlertMessage.value = errorMsg

                    _feedbackEvents.emit(ScanFeedbackEvent.Failure(errorMsg, trimmedToken))
                    onComplete?.invoke(false, null, errorMsg)
                }
            } finally {
                inFlightTokens.remove(trimmedToken)
                _isProcessingScan.value = false
            }
        }
    }

    /**
     * Clears on-screen security alert dialog.
     */
    fun clearScanAlert() {
        _scanAlertMessage.value = null
    }

    /**
     * Clears the success banner.
     */
    fun clearLastScanned() {
        _lastScannedSoldier.value = null
    }

    override fun onCleared() {
        super.onCleared()
        try {
            barcodeScannerInstance?.close()
        } catch (e: Exception) {
            // Ignore
        }
        analysisExecutor.shutdown()
        cameraControl = null
    }

    class Factory(
        private val repository: RollCallRepository,
        private val authManager: AuthManager
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ScannerViewModel(repository, authManager) as T
        }
    }
}
