package com.example.ui.report

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.example.data.model.AttendanceStatus
import com.example.data.model.AttendanceSummary
import com.example.data.model.SoldierAttendanceItem
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Official Military PDF Report Exporter.
 * Generates formatted multi-page tactical roll-call records complying with Scoped Storage.
 */
object PdfExportManager {

    private const val PAGE_WIDTH = 595 // A4 standard width in points (72 dpi)
    private const val PAGE_HEIGHT = 842 // A4 standard height

    fun generateAndSaveDailyReport(
        context: Context,
        date: String,
        commanderName: String,
        unitFilterName: String,
        summary: AttendanceSummary,
        records: List<SoldierAttendanceItem>
    ): Uri? {
        val pdfDocument = PdfDocument()
        val itemsPerPage = 18
        val totalPages = ((records.size - 1) / itemsPerPage + 1).coerceAtLeast(1)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG)

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            // Page Background
            canvas.drawColor(Color.WHITE)

            // Outer Tactical Border
            headerPaint.apply {
                color = Color.parseColor("#2E4D34")
                style = Paint.Style.STROKE
                strokeWidth = 2f
            }
            canvas.drawRect(20f, 20f, PAGE_WIDTH - 20f, PAGE_HEIGHT - 20f, headerPaint)

            // Header Banner
            headerPaint.apply {
                color = Color.parseColor("#1B2E20")
                style = Paint.Style.FILL
            }
            canvas.drawRect(22f, 22f, PAGE_WIDTH - 22f, 75f, headerPaint)

            // Banner Title
            textPaint.apply {
                color = Color.parseColor("#E5C365")
                textSize = 15f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("القيادة العامة للقوات المسلحة - تقرير التمام والجاهزية الميدانية", PAGE_WIDTH / 2f, 45f, textPaint)
            textPaint.apply {
                color = Color.WHITE
                textSize = 10f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            }
            canvas.drawText("ARMED FORCES GENERAL COMMAND • OPERATIONAL ROLL-CALL", PAGE_WIDTH / 2f, 62f, textPaint)

            var y = 95f

            // Metadata Line
            textPaint.apply {
                color = Color.BLACK
                textSize = 9f
                textAlign = Paint.Align.LEFT
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            canvas.drawText("التاريخ (Date): $date", 30f, y, textPaint)
            canvas.drawText("الوحدة (Unit): $unitFilterName", 200f, y, textPaint)
            val printTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            canvas.drawText("وقت الاستخراج: $printTime", 420f, y, textPaint)
            y += 20f

            // Metrics Summary Box (Page 1 only)
            if (pageIndex == 0) {
                val boxRect = RectF(30f, y, PAGE_WIDTH - 30f, y + 42f)
                headerPaint.apply {
                    color = Color.parseColor("#F1F5F2")
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(boxRect, 6f, 6f, headerPaint)
                headerPaint.apply {
                    color = Color.parseColor("#A1B2A4")
                    style = Paint.Style.STROKE
                    strokeWidth = 1f
                }
                canvas.drawRoundRect(boxRect, 6f, 6f, headerPaint)

                textPaint.apply {
                    textSize = 8.5f
                    textAlign = Paint.Align.CENTER
                }
                val colWidth = (PAGE_WIDTH - 60f) / 6f
                val metrics = listOf(
                    "القوة الإجمالية: ${summary.totalSoldiers}",
                    "حاضر: ${summary.presentCount}",
                    "غائب: ${summary.absentCount}",
                    "مرض: ${summary.sickCount}",
                    "إجازة: ${summary.leaveCount}",
                    "نسبة الجاهزية: ${"%.1f".format(summary.presentPercentage)}%"
                )
                metrics.forEachIndexed { i, label ->
                    val cx = 30f + (i + 0.5f) * colWidth
                    textPaint.color = when (i) {
                        1 -> Color.parseColor("#2E7D32")
                        2 -> Color.parseColor("#C62828")
                        5 -> Color.parseColor("#1565C0")
                        else -> Color.BLACK
                    }
                    canvas.drawText(label, cx, y + 25f, textPaint)
                }
                y += 55f
            }

            // Table Header
            val tableTop = y
            headerPaint.apply {
                color = Color.parseColor("#384F3D")
                style = Paint.Style.FILL
            }
            canvas.drawRect(30f, tableTop, PAGE_WIDTH - 30f, tableTop + 22f, headerPaint)

            textPaint.apply {
                color = Color.WHITE
                textSize = 8.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("الرقم العسكري", 70f, tableTop + 15f, textPaint)
            canvas.drawText("الرتبة", 130f, tableTop + 15f, textPaint)
            canvas.drawText("الاسم بالكامل", 240f, tableTop + 15f, textPaint)
            canvas.drawText("الوحدة", 370f, tableTop + 15f, textPaint)
            canvas.drawText("الحالة", 450f, tableTop + 15f, textPaint)
            canvas.drawText("الضابط الراصد", 520f, tableTop + 15f, textPaint)

            y = tableTop + 22f

            // Table Rows
            val startIndex = pageIndex * itemsPerPage
            val endIndex = (startIndex + itemsPerPage).coerceAtMost(records.size)

            for (i in startIndex until endIndex) {
                val item = records[i]
                val rowHeight = 24f

                // Alternating row color
                if (i % 2 == 1) {
                    headerPaint.apply {
                        color = Color.parseColor("#F7FAF7")
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(30f, y, PAGE_WIDTH - 30f, y + rowHeight, headerPaint)
                }

                // Grid Line
                headerPaint.apply {
                    color = Color.parseColor("#E0E0E0")
                    style = Paint.Style.STROKE
                    strokeWidth = 0.5f
                }
                canvas.drawLine(30f, y + rowHeight, PAGE_WIDTH - 30f, y + rowHeight, headerPaint)

                // Row Text
                textPaint.apply {
                    color = Color.BLACK
                    textSize = 8f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText(item.militaryId, 70f, y + 16f, textPaint)
                canvas.drawText(item.rank, 130f, y + 16f, textPaint)
                canvas.drawText(item.fullName, 240f, y + 16f, textPaint)
                canvas.drawText(item.unitName ?: "عام", 370f, y + 16f, textPaint)

                // Status with military color coding
                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textPaint.color = when (item.attendanceStatus) {
                    AttendanceStatus.PRESENT -> Color.parseColor("#2E7D32")
                    AttendanceStatus.ABSENT -> Color.parseColor("#C62828")
                    AttendanceStatus.SICK -> Color.parseColor("#EF6C00")
                    AttendanceStatus.LEAVE -> Color.parseColor("#1565C0")
                    AttendanceStatus.MISSION -> Color.parseColor("#6A1B9A")
                    AttendanceStatus.UNMARKED -> Color.parseColor("#757575")
                }
                canvas.drawText(item.attendanceStatus.labelAr, 450f, y + 16f, textPaint)

                textPaint.color = Color.DKGRAY
                textPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                canvas.drawText(item.markedByOfficerName ?: "آلي (QR)", 520f, y + 16f, textPaint)

                y += rowHeight
            }

            // Footer / Signature Section (Only on Last Page)
            if (pageIndex == totalPages - 1) {
                val sigY = PAGE_HEIGHT - 80f
                textPaint.apply {
                    color = Color.BLACK
                    textSize = 8.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.LEFT
                }
                canvas.drawText("توقيع ضابط التمام:", 60f, sigY, textPaint)
                canvas.drawLine(60f, sigY + 25f, 180f, sigY + 25f, headerPaint)

                canvas.drawText("اعتماد قائد اللواء / الكتيبة:", 380f, sigY, textPaint)
                canvas.drawText(commanderName, 380f, sigY + 18f, textPaint)
                canvas.drawLine(380f, sigY + 25f, 520f, sigY + 25f, headerPaint)
            }

            // Page Number
            textPaint.apply {
                color = Color.GRAY
                textSize = 7.5f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("صفحة ${pageIndex + 1} من $totalPages • وثيقة عسكرية رسمية غير مصرح بتداولها", PAGE_WIDTH / 2f, PAGE_HEIGHT - 28f, textPaint)

            pdfDocument.finishPage(page)
        }

        // Save PDF using MediaStore for Scoped Storage compliance
        val fileName = "Military_RollCall_${date}_${System.currentTimeMillis()}.pdf"
        val values = ContentValues().apply {
            put(MediaStore.Files.FileColumns.DISPLAY_NAME, fileName)
            put(MediaStore.Files.FileColumns.MIME_TYPE, "application/pdf")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Files.FileColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOCUMENTS}/MilitaryRollCall")
                put(MediaStore.Files.FileColumns.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val fileUri = resolver.insert(collection, values) ?: return null

        try {
            resolver.openOutputStream(fileUri)?.use { outputStream: OutputStream ->
                pdfDocument.writeTo(outputStream)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Files.FileColumns.IS_PENDING, 0)
                resolver.update(fileUri, values, null, null)
            }
            pdfDocument.close()

            Toast.makeText(context, "تم حفظ التقرير العسكري بنجاح في المستندات", Toast.LENGTH_LONG).show()

            // Intent to view PDF
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(fileUri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                // Reader not available
            }

            return fileUri
        } catch (e: Exception) {
            resolver.delete(fileUri, null, null)
            pdfDocument.close()
            return null
        }
    }
}
