package com.example.ui.badge

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.SoldierEntity
import com.example.data.model.UnitEntity
import com.example.security.KeyStoreHelper
import com.example.ui.theme.TacticalCardBorder
import com.example.ui.theme.TacticalGold

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSoldierDialog(
    units: List<UnitEntity>,
    onDismiss: () -> Unit,
    onSaveAndPrint: (SoldierEntity, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val ranks = listOf(
        "جندي مقاتل", "عريف", "رقيب", "رقيب أول",
        "مساعد", "ملازم", "ملازم أول", "نقيب", "رائد", "مقدم", "عقيد"
    )
    val bloodTypes = listOf("O+", "A+", "B+", "AB+", "O-", "A-", "B-", "AB-")
    val weapons = listOf(
        "M4A1 Carbine (5.56mm)",
        "AK-103 Tactical (7.62mm)",
        "SIG Sauer MCX (5.56mm)",
        "Glock 19 Gen5 (9mm)",
        "FN SCAR-H (7.62mm)",
        "Beretta M9 (9mm)"
    )

    var militaryId by remember { mutableStateOf("MIL-%05d".format((10050..99999).random())) }
    var fullName by remember { mutableStateOf("") }
    var selectedRank by remember { mutableStateOf(ranks.first()) }
    var selectedUnitId by remember { mutableStateOf(units.firstOrNull()?.unitId ?: 1L) }
    var selectedBloodType by remember { mutableStateOf(bloodTypes.first()) }
    var selectedWeapon by remember { mutableStateOf(weapons.first()) }

    var rankDropdownExpanded by remember { mutableStateOf(false) }
    var unitDropdownExpanded by remember { mutableStateOf(false) }
    var bloodDropdownExpanded by remember { mutableStateOf(false) }
    var weaponDropdownExpanded by remember { mutableStateOf(false) }

    var previewBadgeBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var createdSoldier by remember { mutableStateOf<SoldierEntity?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp))
                .testTag("add_soldier_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, TacticalCardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Badge,
                            contentDescription = null,
                            tint = TacticalGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (createdSoldier == null) "إصدار بطاقة وهوية عسكرية جديدة" else "معاينة البطاقة العسكرية المعتمدة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "إلغاء")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (createdSoldier == null) {
                    // Registration Form

                    // Military ID
                    OutlinedTextField(
                        value = militaryId,
                        onValueChange = { militaryId = it },
                        label = { Text("الرقم العسكري (Military ID)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_military_id_input"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = TacticalCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Full Name
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("الاسم بالكامل (ثلاثي أو رباعي)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_soldier_name_input"),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = TacticalCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Rank Dropdown
                    ExposedDropdownMenuBox(
                        expanded = rankDropdownExpanded,
                        onExpandedChange = { rankDropdownExpanded = !rankDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedRank,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الرتبة العسكرية") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = rankDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = rankDropdownExpanded,
                            onDismissRequest = { rankDropdownExpanded = false }
                        ) {
                            ranks.forEach { rank ->
                                DropdownMenuItem(
                                    text = { Text(rank) },
                                    onClick = {
                                        selectedRank = rank
                                        rankDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Unit Dropdown
                    val currentUnitName = units.find { it.unitId == selectedUnitId }?.unitName ?: "اختر الوحدة"
                    ExposedDropdownMenuBox(
                        expanded = unitDropdownExpanded,
                        onExpandedChange = { unitDropdownExpanded = !unitDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = currentUnitName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الوحدة / الكتيبة") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = unitDropdownExpanded,
                            onDismissRequest = { unitDropdownExpanded = false }
                        ) {
                            units.forEach { unit ->
                                DropdownMenuItem(
                                    text = { Text(unit.unitName) },
                                    onClick = {
                                        selectedUnitId = unit.unitId
                                        unitDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Blood Type & Weapon Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Blood Type
                        ExposedDropdownMenuBox(
                            expanded = bloodDropdownExpanded,
                            onExpandedChange = { bloodDropdownExpanded = !bloodDropdownExpanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = selectedBloodType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("فصيلة الدم") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bloodDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = bloodDropdownExpanded,
                                onDismissRequest = { bloodDropdownExpanded = false }
                            ) {
                                bloodTypes.forEach { blood ->
                                    DropdownMenuItem(
                                        text = { Text(blood) },
                                        onClick = {
                                            selectedBloodType = blood
                                            bloodDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        // Weapon
                        ExposedDropdownMenuBox(
                            expanded = weaponDropdownExpanded,
                            onExpandedChange = { weaponDropdownExpanded = !weaponDropdownExpanded },
                            modifier = Modifier.weight(2f)
                        ) {
                            OutlinedTextField(
                                value = selectedWeapon,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("السلاح المسند") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = weaponDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = weaponDropdownExpanded,
                                onDismissRequest = { weaponDropdownExpanded = false }
                            ) {
                                weapons.forEach { w ->
                                    DropdownMenuItem(
                                        text = { Text(w) },
                                        onClick = {
                                            selectedWeapon = w
                                            weaponDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (fullName.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال اسم الفرد بالكامل", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val secureToken = KeyStoreHelper.generateSecureQrToken()
                                val soldier = SoldierEntity(
                                    militaryId = militaryId.trim(),
                                    fullName = fullName.trim(),
                                    rank = selectedRank,
                                    unitId = selectedUnitId,
                                    bloodType = selectedBloodType,
                                    assignedWeapon = selectedWeapon,
                                    qrToken = secureToken,
                                    isActive = true
                                )
                                createdSoldier = soldier
                                val unitName = units.find { it.unitId == selectedUnitId }?.unitName ?: "الوحدة العسكرية"
                                previewBadgeBitmap = BadgePrintManager.renderMilitaryBadge(soldier, unitName)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("generate_badge_preview_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("توليد ومعاينة البطاقة")
                        }
                    }
                } else {
                    // Preview & Print Section
                    createdSoldier?.let { soldier ->
                        val unitName = units.find { it.unitId == soldier.unitId }?.unitName ?: "الوحدة الميدانية"

                        previewBadgeBitmap?.let { bmp ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, TacticalGold, RoundedCornerShape(8.dp)),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Image(
                                    bitmap = bmp.asImageBitmap(),
                                    contentDescription = "معاينة البطاقة العسكرية CR80",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Security Token verification notice
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "الرمز المشفر المدمج (Cryptographic Token):",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TacticalGold
                                )
                                Text(
                                    text = soldier.qrToken,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Print Button
                            Button(
                                onClick = {
                                    onSaveAndPrint(soldier, true)
                                    BadgePrintManager.printBadge(context, soldier, unitName)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("confirm_print_badge_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Print, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("طباعة البطاقة")
                            }

                            // Save Image Button
                            OutlinedButton(
                                onClick = {
                                    val uri = BadgePrintManager.saveBadgeToStorage(context, soldier, unitName)
                                    if (uri != null) {
                                        Toast.makeText(context, "تم حفظ البطاقة في معرض الصور / المستندات", Toast.LENGTH_SHORT).show()
                                    }
                                    onSaveAndPrint(soldier, false)
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("save_badge_image_button"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Download, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("حفظ بالهاتف")
                            }
                        }
                    }
                }
            }
        }
    }
}
