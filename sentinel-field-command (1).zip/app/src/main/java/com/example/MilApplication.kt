package com.example

import android.app.Application
import android.util.Log

class MilApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        try {
            System.loadLibrary("sqlcipher")
            Log.i("MilApplication", "SQLCipher native library initialized successfully.")
        } catch (t: Throwable) {
            Log.w("MilApplication", "Native SQLCipher library load skipped or failed: ${t.message}")
        }
    }
}
