package com.example.security

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Enforces Role-Based Access Control (RBAC) and military credentials gate.
 */
class AuthManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("mil_rbac_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ADMIN_PIN_HASH = "admin_pin_hash"
        private const val KEY_RECORDER_PIN_HASH = "recorder_pin_hash"

        // Default PINs for operational field initialization
        const val DEFAULT_ADMIN_PIN = "9999"
        const val DEFAULT_RECORDER_PIN = "1111"
    }

    private val _currentRole = MutableStateFlow<UserRole?>(null)
    val currentRole: StateFlow<UserRole?> = _currentRole.asStateFlow()

    private val _officerName = MutableStateFlow("الملازم أول / أحمد محمود")
    val officerName: StateFlow<String> = _officerName.asStateFlow()

    init {
        // Ensure default PIN hashes exist
        if (!prefs.contains(KEY_ADMIN_PIN_HASH)) {
            savePinHash(KEY_ADMIN_PIN_HASH, DEFAULT_ADMIN_PIN)
        }
        if (!prefs.contains(KEY_RECORDER_PIN_HASH)) {
            savePinHash(KEY_RECORDER_PIN_HASH, DEFAULT_RECORDER_PIN)
        }
    }

    /**
     * Authenticates with entered PIN and determines Role.
     * Returns UserRole if authenticated, null otherwise.
     */
    fun authenticate(pin: String, officerCallsign: String? = null): UserRole? {
        val trimmedPin = pin.trim()
        val role = when {
            verifyPin(KEY_ADMIN_PIN_HASH, trimmedPin) -> {
                _officerName.value = prefs.getString("admin_name", "العقيد / قائد اللواء") ?: "العقيد / قائد اللواء"
                UserRole.ROLE_ADMIN
            }
            verifyPin(KEY_RECORDER_PIN_HASH, trimmedPin) -> {
                _officerName.value = prefs.getString("recorder_name", "الملازم / ضابط الرصد") ?: "الملازم / ضابط الرصد"
                UserRole.ROLE_RECORDER
            }
            else -> {
                // Check dynamically added users
                val dynamicUsers = getDynamicUsersList()
                val matched = dynamicUsers.find { verifyPin("user_pin_${it.id}", trimmedPin) }
                if (matched != null) {
                    _officerName.value = matched.name
                    matched.role
                } else null
            }
        }

        if (role != null) {
            _currentRole.value = role
            if (!officerCallsign.isNullOrBlank()) {
                _officerName.value = officerCallsign.trim()
            }
        }
        return role
    }

    fun logout() {
        _currentRole.value = null
    }

    // RBAC Permission checks
    fun canPerformManualRollCall(): Boolean = _currentRole.value == UserRole.ROLE_ADMIN
    fun canModifyStatusToLeaveOrSick(): Boolean = _currentRole.value == UserRole.ROLE_ADMIN
    fun canAddOrEditSoldier(): Boolean = _currentRole.value == UserRole.ROLE_ADMIN
    fun canExportPdfReports(): Boolean = _currentRole.value == UserRole.ROLE_ADMIN
    fun canAccessCameraScanner(): Boolean = _currentRole.value != null

    // 1. Roll-Call Timing & Rules Settings
    fun getRollCallStartTime(): String = prefs.getString("setting_start_time", "07:00") ?: "07:00"
    fun setRollCallStartTime(time: String) = prefs.edit().putString("setting_start_time", time).apply()

    fun getRollCallEndTime(): String = prefs.getString("setting_end_time", "08:00") ?: "08:00"
    fun setRollCallEndTime(time: String) = prefs.edit().putString("setting_end_time", time).apply()

    fun isAllowRepeatScan(): Boolean = prefs.getBoolean("setting_allow_repeat", false)
    fun setAllowRepeatScan(allow: Boolean) = prefs.edit().putBoolean("setting_allow_repeat", allow).apply()

    fun isAlertOnRepeatScan(): Boolean = prefs.getBoolean("setting_alert_repeat", true)
    fun setAlertOnRepeatScan(alert: Boolean) = prefs.edit().putBoolean("setting_alert_repeat", alert).apply()

    fun getDefaultUnmarkedStatus(): String = prefs.getString("setting_default_unmarked", "ABSENT") ?: "ABSENT"
    fun setDefaultUnmarkedStatus(status: String) = prefs.edit().putString("setting_default_unmarked", status).apply()

    // 2. User & PIN Management
    fun changeAdminPin(oldPin: String, newPin: String): Boolean {
        if (!verifyPin(KEY_ADMIN_PIN_HASH, oldPin.trim())) return false
        savePinHash(KEY_ADMIN_PIN_HASH, newPin.trim())
        return true
    }

    fun changeRecorderPin(newPin: String) {
        savePinHash(KEY_RECORDER_PIN_HASH, newPin.trim())
    }

    private fun getDynamicUsersList(): List<com.example.data.model.OfficerUser> {
        val raw = prefs.getString("dynamic_users_json", "[]") ?: "[]"
        val list = mutableListOf<com.example.data.model.OfficerUser>()
        try {
            val arr = org.json.JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    com.example.data.model.OfficerUser(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        role = UserRole.valueOf(obj.getString("role")),
                        pin = "••••"
                    )
                )
            }
        } catch (e: Exception) {
            // Ignore
        }
        return list
    }

    private fun saveDynamicUsersList(list: List<com.example.data.model.OfficerUser>) {
        val arr = org.json.JSONArray()
        list.forEach { u ->
            val obj = org.json.JSONObject().apply {
                put("id", u.id)
                put("name", u.name)
                put("role", u.role.name)
            }
            arr.put(obj)
        }
        prefs.edit().putString("dynamic_users_json", arr.toString()).apply()
    }

    fun listUsers(): List<com.example.data.model.OfficerUser> {
        val list = mutableListOf<com.example.data.model.OfficerUser>()
        list.add(
            com.example.data.model.OfficerUser(
                id = "admin_01",
                name = prefs.getString("admin_name", "العقيد / قائد التمام") ?: "العقيد / قائد التمام",
                role = UserRole.ROLE_ADMIN,
                pin = "••••"
            )
        )
        list.add(
            com.example.data.model.OfficerUser(
                id = "recorder_01",
                name = prefs.getString("recorder_name", "الملازم / ضابط الرصد الميداني") ?: "الملازم / ضابط الرصد الميداني",
                role = UserRole.ROLE_RECORDER,
                pin = "••••"
            )
        )
        list.addAll(getDynamicUsersList())
        return list
    }

    fun updateUserName(userId: String, newName: String) {
        if (userId == "admin_01") {
            prefs.edit().putString("admin_name", newName).apply()
            if (_currentRole.value == UserRole.ROLE_ADMIN) _officerName.value = newName
        } else if (userId == "recorder_01") {
            prefs.edit().putString("recorder_name", newName).apply()
            if (_currentRole.value == UserRole.ROLE_RECORDER) _officerName.value = newName
        } else {
            val list = getDynamicUsersList().map {
                if (it.id == userId) it.copy(name = newName) else it
            }
            saveDynamicUsersList(list)
        }
    }

    fun addUser(name: String, pin: String, role: UserRole) {
        val newId = "user_${System.currentTimeMillis()}"
        savePinHash("user_pin_$newId", pin)
        val current = getDynamicUsersList().toMutableList()
        current.add(com.example.data.model.OfficerUser(id = newId, name = name, role = role, pin = "••••"))
        saveDynamicUsersList(current)
    }

    fun deleteUser(userId: String): Boolean {
        if (userId == "admin_01" || userId == "recorder_01") return false
        val current = getDynamicUsersList().toMutableList()
        val removed = current.removeAll { it.id == userId }
        if (removed) {
            saveDynamicUsersList(current)
            prefs.edit().remove("user_pin_$userId").apply()
        }
        return removed
    }

    // 3. Badge Printing Customization Settings
    fun getBadgeOrgName(): String = prefs.getString("badge_org_name", "القيادة العامة للقوات المسلحة") ?: "القيادة العامة للقوات المسلحة"
    fun setBadgeOrgName(orgName: String) = prefs.edit().putString("badge_org_name", orgName).apply()

    fun isBadgeShowCrest(): Boolean = prefs.getBoolean("badge_show_crest", true)
    fun setBadgeShowCrest(show: Boolean) = prefs.edit().putBoolean("badge_show_crest", show).apply()

    fun isBadgeShowSoldierName(): Boolean = prefs.getBoolean("badge_show_name", true)
    fun setBadgeShowSoldierName(show: Boolean) = prefs.edit().putBoolean("badge_show_name", show).apply()

    fun isBadgeShowMilitaryId(): Boolean = prefs.getBoolean("badge_show_military_id", true)
    fun setBadgeShowMilitaryId(show: Boolean) = prefs.edit().putBoolean("badge_show_military_id", show).apply()

    fun isBadgeShowQrCode(): Boolean = prefs.getBoolean("badge_show_qr", true)
    fun setBadgeShowQrCode(show: Boolean) = prefs.edit().putBoolean("badge_show_qr", show).apply()

    fun isBadgeShowBlood(): Boolean = prefs.getBoolean("badge_show_blood", true)
    fun setBadgeShowBlood(show: Boolean) = prefs.edit().putBoolean("badge_show_blood", show).apply()

    fun isBadgeShowWeapon(): Boolean = prefs.getBoolean("badge_show_weapon", true)
    fun setBadgeShowWeapon(show: Boolean) = prefs.edit().putBoolean("badge_show_weapon", show).apply()

    // 4. Backup & Remote Central Sync Settings
    fun getBackupDestinationType(): String = prefs.getString("backup_dest_type", "LOCAL") ?: "LOCAL"
    fun setBackupDestinationType(type: String) = prefs.edit().putString("backup_dest_type", type).apply()

    fun getCentralServerUrl(): String = prefs.getString("backup_server_url", "http://192.168.1.100:8080/sync") ?: "http://192.168.1.100:8080/sync"
    fun setCentralServerUrl(url: String) = prefs.edit().putString("backup_server_url", url).apply()

    private fun savePinHash(key: String, pin: String) {
        val hash = hashPin(pin)
        prefs.edit().putString(key, hash).apply()
    }

    private fun verifyPin(key: String, pin: String): Boolean {
        val storedHash = prefs.getString(key, null) ?: return false
        return storedHash == hashPin(pin)
    }

    private fun hashPin(pin: String): String {
        val bytes = java.security.MessageDigest.getInstance("SHA-256")
            .digest(("MIL_SALT_" + pin).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
