package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AttendanceDao
import com.example.data.dao.SoldierDao
import com.example.data.dao.UnitDao
import com.example.data.model.AttendanceEntity
import com.example.data.model.SoldierEntity
import com.example.data.model.SoldierFtsEntity
import com.example.data.model.UnitEntity
import com.example.security.KeyStoreHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory as SupportFactory

@Database(
    entities = [
        SoldierEntity::class,
        SoldierFtsEntity::class,
        UnitEntity::class,
        AttendanceEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun soldierDao(): SoldierDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun unitDao(): UnitDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private const val DB_NAME = "vanguard_tactical_encrypted.db"

        fun getInstance(context: Context, masterPin: String = "9999"): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext, masterPin).also { INSTANCE = it }
            }
        }

        fun checkpointDatabase(context: Context) {
            try {
                INSTANCE?.let { db ->
                    if (db.isOpen) {
                        val cursor = db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)")
                        cursor.close()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("AppDatabase", "Checkpoint warning: ${e.message}")
            }
        }

        fun closeAndResetInstance() {
            synchronized(this) {
                try {
                    INSTANCE?.close()
                } catch (e: Exception) {
                    android.util.Log.w("AppDatabase", "Error closing database: ${e.message}")
                }
                INSTANCE = null
            }
        }

        private fun buildDatabase(context: Context, masterPin: String): AppDatabase {
            var isSqlCipherLoaded = false
            try {
                System.loadLibrary("sqlcipher")
                isSqlCipherLoaded = true
            } catch (t: Throwable) {
                android.util.Log.w("AppDatabase", "Native sqlcipher load warning: ${t.message}")
            }

            val builder = Room.databaseBuilder(context, AppDatabase::class.java, DB_NAME)
                .fallbackToDestructiveMigration()
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed tactical data asynchronously
                        CoroutineScope(Dispatchers.IO).launch {
                            seedDatabase(getInstance(context, masterPin))
                        }
                    }
                })

            if (isSqlCipherLoaded) {
                try {
                    // Derive 256-bit encryption key combining AndroidKeyStore hardware entropy + Master PIN
                    val passphrase: ByteArray = KeyStoreHelper.deriveDatabasePassphrase(masterPin)
                    val factory: SupportFactory = SupportFactory(passphrase)
                    builder.openHelperFactory(factory)
                } catch (t: Throwable) {
                    android.util.Log.e("AppDatabase", "Failed to configure SQLCipher SupportFactory", t)
                }
            }

            return builder.build()
        }

        /**
         * Helper method to instantiate SupportFactory using the encrypted passphrase
         * derived from the KeyStore and master PIN.
         */
        fun createSupportFactory(masterPin: String): SupportFactory {
            val passphrase = KeyStoreHelper.deriveDatabasePassphrase(masterPin)
            return SupportFactory(passphrase)
        }

        private suspend fun seedDatabase(database: AppDatabase) {
            val unitDao = database.unitDao()
            val soldierDao = database.soldierDao()

            if (unitDao.getUnitCount() > 0) return

            // 1. Seed Operational Units
            val units = listOf(
                UnitEntity(unitId = 1, unitName = "كتيبة المشاة الأولى (1st Infantry Bn)", commanderName = "العقيد / حسام الدين", codeSymbol = "INF-01"),
                UnitEntity(unitId = 2, unitName = "سرية الاستطلاع الخاص (Recon Coy)", commanderName = "الرائد / طارق خالد", codeSymbol = "RCN-02"),
                UnitEntity(unitId = 3, unitName = "كتيبة الدروع والمدفعية (Armored Bn)", commanderName = "المقدم / يحيى سليم", codeSymbol = "ARM-03"),
                UnitEntity(unitId = 4, unitName = "سرية الإشارة والاتصالات (Signals Coy)", commanderName = "النقيب / عمر فاروق", codeSymbol = "SIG-04"),
                UnitEntity(unitId = 5, unitName = "فصيلة الخدمات الطبية الميدانية (Medical Plt)", commanderName = "الرائد طبيب / نبيل كمال", codeSymbol = "MED-05")
            )
            unitDao.insertUnits(units)

            // 2. Seed Military Personnel with secure QR tokens
            val ranks = listOf("جندي", "عريف", "رقيب", "رقيب أول", "مساعد", "ملازم", "ملازم أول", "نقيب", "رائد")
            val bloodTypes = listOf("O+", "A+", "B+", "AB+", "O-", "A-")
            val weapons = listOf("M4A1 Carbine", "AK-103 Tactical", "SIG Sauer MCX", "Glock 19 Gen5", "FN SCAR-H", "Beretta M9")

            val firstNames = listOf("أحمد", "محمد", "علي", "محمود", "عمر", "خالد", "يوسف", "حسن", "حسين", "إبراهيم", "كريم", "طارق", "سامي", "زياد", "أيمن", "فهد", "عبدالله", "سعد", "ماجد", "رامي")
            val lastNames = listOf("السيد", "إبراهيم", "محمود", "خليل", "الشريف", "منصور", "النجار", "الغامدي", "العنزي", "الحداد", "رمضان", "الصاوي", "العتيبي", "سليمان", "زهران", "المصري", "جابر", "عاصم", "الشناوي", "بدوي")

            val soldiersList = mutableListOf<SoldierEntity>()

            // Guarantee a few fixed demonstration soldiers for instant testing
            soldiersList.add(
                SoldierEntity(
                    militaryId = "MIL-10001",
                    fullName = "محمد أحمد عبد الرحيم",
                    rank = "رقيب أول",
                    unitId = 1,
                    bloodType = "O+",
                    assignedWeapon = "M4A1 Carbine",
                    qrToken = "MIL-DEMO-TOKEN-ALPHA-01"
                )
            )
            soldiersList.add(
                SoldierEntity(
                    militaryId = "MIL-10002",
                    fullName = "عمر طارق الشريف",
                    rank = "ملازم أول",
                    unitId = 2,
                    bloodType = "A+",
                    assignedWeapon = "SIG Sauer MCX",
                    qrToken = "MIL-DEMO-TOKEN-BRAVO-02"
                )
            )
            soldiersList.add(
                SoldierEntity(
                    militaryId = "MIL-10003",
                    fullName = "خالد إبراهيم المنصور",
                    rank = "جندي مقاتل",
                    unitId = 1,
                    bloodType = "B+",
                    assignedWeapon = "AK-103 Tactical",
                    qrToken = "MIL-DEMO-TOKEN-CHARLIE-03"
                )
            )

            // Seed up to 50 active personnel across all units
            for (i in 4..50) {
                val fName = firstNames[(i * 3 + 7) % firstNames.size]
                val lName = lastNames[(i * 5 + 3) % lastNames.size]
                val rank = ranks[i % ranks.size]
                val unitId = ((i % units.size) + 1).toLong()
                val blood = bloodTypes[i % bloodTypes.size]
                val weapon = weapons[i % weapons.size]
                val militaryId = "MIL-%05d".format(10000 + i)
                val token = KeyStoreHelper.generateSecureQrToken()

                soldiersList.add(
                    SoldierEntity(
                        militaryId = militaryId,
                        fullName = "$fName $lName",
                        rank = rank,
                        unitId = unitId,
                        bloodType = blood,
                        assignedWeapon = weapon,
                        qrToken = token,
                        isActive = true
                    )
                )
            }

            soldierDao.insertSoldiers(soldiersList)
        }
    }
}
