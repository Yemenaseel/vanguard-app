package com.example.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.OfficerUser
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "vanguard_tactical_settings")

data class AttendanceTimingSettings(
    val startTime: String = "07:00",
    val endTime: String = "08:00",
    val allowRepeatScan: Boolean = false,
    val alertOnRepeatScan: Boolean = true,
    val defaultUnmarkedStatus: String = "ABSENT"
)

data class CardTemplateSettings(
    val orgName: String = "القوات المسلحة - قيادة العمليات",
    val showCrest: Boolean = true,
    val showSoldierName: Boolean = true,
    val showMilitaryId: Boolean = true,
    val showQrCode: Boolean = true,
    val showBlood: Boolean = true,
    val showWeapon: Boolean = true,
    val templateColor: String = "GOLD" // GOLD, DESERT, CAMO, NAVY
)

data class BackupSettings(
    val destinationType: String = "LOCAL", // "LOCAL" or "SERVER"
    val centralServerUrl: String = "http://192.168.1.100:8080/sync",
    val lastBackupTimestamp: Long = 0L,
    val lastBackupFileName: String = ""
)

class SettingsDataStore(private val context: Context) {

    companion object {
        // Attendance Window Timing
        val KEY_START_TIME = stringPreferencesKey("attendance_start_time")
        val KEY_END_TIME = stringPreferencesKey("attendance_end_time")
        val KEY_ALLOW_REPEAT = booleanPreferencesKey("attendance_allow_repeat")
        val KEY_ALERT_REPEAT = booleanPreferencesKey("attendance_alert_repeat")
        val KEY_DEFAULT_UNMARKED = stringPreferencesKey("attendance_default_unmarked")

        // User Management
        val KEY_USERS_JSON = stringPreferencesKey("user_management_json")

        // Backup / Restore
        val KEY_BACKUP_DEST = stringPreferencesKey("backup_destination")
        val KEY_SERVER_URL = stringPreferencesKey("backup_server_url")
        val KEY_LAST_BACKUP_TIME = longPreferencesKey("backup_last_timestamp")
        val KEY_LAST_BACKUP_NAME = stringPreferencesKey("backup_last_filename")

        // Card Template Configuration
        val KEY_ORG_NAME = stringPreferencesKey("card_org_name")
        val KEY_SHOW_CREST = booleanPreferencesKey("card_show_crest")
        val KEY_SHOW_SOLDIER_NAME = booleanPreferencesKey("card_show_soldier_name")
        val KEY_SHOW_MILITARY_ID = booleanPreferencesKey("card_show_military_id")
        val KEY_SHOW_QR_CODE = booleanPreferencesKey("card_show_qr_code")
        val KEY_SHOW_BLOOD = booleanPreferencesKey("card_show_blood")
        val KEY_SHOW_WEAPON = booleanPreferencesKey("card_show_weapon")
        val KEY_TEMPLATE_COLOR = stringPreferencesKey("card_template_color")
    }

    // 1. Attendance Timing Flow
    val attendanceTimingFlow: Flow<AttendanceTimingSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { prefs ->
            AttendanceTimingSettings(
                startTime = prefs[KEY_START_TIME] ?: "07:00",
                endTime = prefs[KEY_END_TIME] ?: "08:00",
                allowRepeatScan = prefs[KEY_ALLOW_REPEAT] ?: false,
                alertOnRepeatScan = prefs[KEY_ALERT_REPEAT] ?: true,
                defaultUnmarkedStatus = prefs[KEY_DEFAULT_UNMARKED] ?: "ABSENT"
            )
        }

    suspend fun updateAttendanceTiming(settings: AttendanceTimingSettings) {
        context.dataStore.edit { prefs ->
            prefs[KEY_START_TIME] = settings.startTime
            prefs[KEY_END_TIME] = settings.endTime
            prefs[KEY_ALLOW_REPEAT] = settings.allowRepeatScan
            prefs[KEY_ALERT_REPEAT] = settings.alertOnRepeatScan
            prefs[KEY_DEFAULT_UNMARKED] = settings.defaultUnmarkedStatus
        }
    }

    // 2. Card Template Flow
    val cardTemplateFlow: Flow<CardTemplateSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { prefs ->
            CardTemplateSettings(
                orgName = prefs[KEY_ORG_NAME] ?: "القوات المسلحة - قيادة العمليات",
                showCrest = prefs[KEY_SHOW_CREST] ?: true,
                showSoldierName = prefs[KEY_SHOW_SOLDIER_NAME] ?: true,
                showMilitaryId = prefs[KEY_SHOW_MILITARY_ID] ?: true,
                showQrCode = prefs[KEY_SHOW_QR_CODE] ?: true,
                showBlood = prefs[KEY_SHOW_BLOOD] ?: true,
                showWeapon = prefs[KEY_SHOW_WEAPON] ?: true,
                templateColor = prefs[KEY_TEMPLATE_COLOR] ?: "GOLD"
            )
        }

    suspend fun updateCardTemplate(settings: CardTemplateSettings) {
        context.dataStore.edit { prefs ->
            prefs[KEY_ORG_NAME] = settings.orgName
            prefs[KEY_SHOW_CREST] = settings.showCrest
            prefs[KEY_SHOW_SOLDIER_NAME] = settings.showSoldierName
            prefs[KEY_SHOW_MILITARY_ID] = settings.showMilitaryId
            prefs[KEY_SHOW_QR_CODE] = settings.showQrCode
            prefs[KEY_SHOW_BLOOD] = settings.showBlood
            prefs[KEY_SHOW_WEAPON] = settings.showWeapon
            prefs[KEY_TEMPLATE_COLOR] = settings.templateColor
        }
    }

    // 3. Backup Settings Flow
    val backupSettingsFlow: Flow<BackupSettings> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { prefs ->
            BackupSettings(
                destinationType = prefs[KEY_BACKUP_DEST] ?: "LOCAL",
                centralServerUrl = prefs[KEY_SERVER_URL] ?: "http://192.168.1.100:8080/sync",
                lastBackupTimestamp = prefs[KEY_LAST_BACKUP_TIME] ?: 0L,
                lastBackupFileName = prefs[KEY_LAST_BACKUP_NAME] ?: ""
            )
        }

    suspend fun updateBackupSettings(settings: BackupSettings) {
        context.dataStore.edit { prefs ->
            prefs[KEY_BACKUP_DEST] = settings.destinationType
            prefs[KEY_SERVER_URL] = settings.centralServerUrl
            prefs[KEY_LAST_BACKUP_TIME] = settings.lastBackupTimestamp
            prefs[KEY_LAST_BACKUP_NAME] = settings.lastBackupFileName
        }
    }

    suspend fun recordSuccessfulBackup(fileName: String, timestamp: Long = System.currentTimeMillis()) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_BACKUP_TIME] = timestamp
            prefs[KEY_LAST_BACKUP_NAME] = fileName
        }
    }

    // 4. User Management DataStore persistence
    val usersListFlow: Flow<List<OfficerUser>> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) emit(emptyPreferences()) else throw exception
        }
        .map { prefs ->
            val json = prefs[KEY_USERS_JSON] ?: "[]"
            parseUsersJson(json)
        }

    suspend fun saveUsersList(users: List<OfficerUser>) {
        val jsonArray = JSONArray()
        users.forEach { u ->
            val obj = JSONObject().apply {
                put("id", u.id)
                put("name", u.name)
                put("role", u.role.name)
                put("pin", u.pin)
            }
            jsonArray.put(obj)
        }
        context.dataStore.edit { prefs ->
            prefs[KEY_USERS_JSON] = jsonArray.toString()
        }
    }

    private fun parseUsersJson(json: String): List<OfficerUser> {
        val list = mutableListOf<OfficerUser>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    OfficerUser(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        role = UserRole.valueOf(obj.getString("role")),
                        pin = obj.optString("pin", "••••")
                    )
                )
            }
        } catch (e: Exception) {
            // fallback
        }
        return list
    }
}
