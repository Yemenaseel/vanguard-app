package com.example.data.repository

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.room.withTransaction
import com.example.data.dao.AttendanceDao
import com.example.data.dao.DailyRawCounts
import com.example.data.dao.SoldierDao
import com.example.data.dao.UnitDao
import com.example.data.db.AppDatabase
import com.example.data.model.AttendanceEntity
import com.example.data.model.AttendanceStatus
import com.example.data.model.SoldierAttendanceItem
import com.example.data.model.SoldierEntity
import com.example.data.model.AttendanceSummary
import com.example.data.model.UnitEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RollCallRepository(
    private val database: AppDatabase,
    private val soldierDao: SoldierDao,
    private val attendanceDao: AttendanceDao,
    private val unitDao: UnitDao
) {

    /**
     * Virtualized Paging 3 stream supporting 5,000+ records seamlessly.
     */
    fun getSoldiersPagingFlow(
        date: String,
        unitId: Long?,
        query: String
    ): Flow<PagingData<SoldierAttendanceItem>> {
        return Pager(
            config = PagingConfig(
                pageSize = 30,
                prefetchDistance = 10,
                enablePlaceholders = false,
                initialLoadSize = 40
            ),
            pagingSourceFactory = {
                attendanceDao.getSoldiersWithAttendancePaging(
                    date = date,
                    unitId = unitId,
                    query = query.trim()
                )
            }
        ).flow
    }

    /**
     * Real-time aggregate metrics flow for the tactical dashboard.
     */
    fun getDailyAttendanceSummary(date: String): Flow<AttendanceSummary> {
        return attendanceDao.getDailyAttendanceCounts(date).map { counts ->
            val total = counts.totalSoldiers
            val marked = counts.presentCount + counts.absentCount + counts.sickCount + counts.leaveCount + counts.missionCount
            val unmarked = (total - marked).coerceAtLeast(0)

            AttendanceSummary(
                totalSoldiers = total,
                presentCount = counts.presentCount,
                absentCount = counts.absentCount,
                sickCount = counts.sickCount,
                leaveCount = counts.leaveCount,
                missionCount = counts.missionCount,
                unmarkedCount = unmarked
            )
        }
    }

    /**
     * Resolves scanned non-plaintext QR token against the encrypted database.
     * Atomically updates attendance to PRESENT if valid.
     */
    suspend fun recordQrScanAttendance(
        scannedToken: String,
        officerName: String,
        role: String
    ): Result<SoldierEntity> = withContext(Dispatchers.IO) {
        val trimmedToken = scannedToken.trim()
        val soldier = soldierDao.findByQrToken(trimmedToken)
            ?: return@withContext Result.failure(Exception("بطاقة غير مصرح بها أو غير مسجلة في قاعدة البيانات العسكرية"))

        val todayDate = getTodayDateString()
        val record = AttendanceEntity(
            militaryId = soldier.militaryId,
            date = todayDate,
            timestamp = System.currentTimeMillis(),
            status = AttendanceStatus.PRESENT,
            recordedByRole = role,
            markedByOfficerName = officerName
        )
        attendanceDao.recordAttendance(record)
        Result.success(soldier)
    }

    /**
     * Updates attendance status manually (ROLE_ADMIN only).
     */
    suspend fun updateAttendanceStatus(
        militaryId: String,
        date: String,
        status: AttendanceStatus,
        officerName: String,
        role: String
    ) = withContext(Dispatchers.IO) {
        val existing = attendanceDao.getAttendanceForSoldier(militaryId, date)
        if (existing != null) {
            attendanceDao.updateAttendanceStatus(
                militaryId = militaryId,
                date = date,
                status = status,
                timestamp = System.currentTimeMillis(),
                role = role,
                officerName = officerName
            )
        } else {
            attendanceDao.recordAttendance(
                AttendanceEntity(
                    militaryId = militaryId,
                    date = date,
                    timestamp = System.currentTimeMillis(),
                    status = status,
                    recordedByRole = role,
                    markedByOfficerName = officerName
                )
            )
        }
    }

    /**
     * Atomically marks all active personnel as PRESENT in a single Room @Transaction.
     */
    suspend fun markAllActiveAsPresent(
        date: String,
        officerName: String,
        role: String
    ) = withContext(Dispatchers.IO) {
        val allSoldiers = soldierDao.getAllSoldiers().first()
        attendanceDao.markAllActiveAsPresent(
            soldiers = allSoldiers,
            date = date,
            timestamp = System.currentTimeMillis(),
            role = role,
            officerName = officerName
        )
    }

    suspend fun addSoldier(soldier: SoldierEntity) = withContext(Dispatchers.IO) {
        soldierDao.insertSoldier(soldier)
    }

    suspend fun updateSoldier(soldier: SoldierEntity) = withContext(Dispatchers.IO) {
        soldierDao.updateSoldier(soldier)
    }

    suspend fun deleteSoldier(soldier: SoldierEntity) = withContext(Dispatchers.IO) {
        soldierDao.deleteSoldier(soldier)
    }

    suspend fun setSoldierActiveStatus(militaryId: String, isActive: Boolean): Boolean = withContext(Dispatchers.IO) {
        soldierDao.setSoldierActiveStatus(militaryId, isActive) > 0
    }

    suspend fun reIssueQrToken(militaryId: String, newQrToken: String): Boolean = withContext(Dispatchers.IO) {
        soldierDao.reIssueQrToken(militaryId, newQrToken) > 0
    }

    suspend fun getSoldierByMilitaryId(militaryId: String): SoldierEntity? = withContext(Dispatchers.IO) {
        soldierDao.findByMilitaryId(militaryId)
    }

    suspend fun getSoldierAttendanceHistory(militaryId: String): List<AttendanceEntity> = withContext(Dispatchers.IO) {
        attendanceDao.getSoldierAttendanceHistory(militaryId)
    }

    fun getAttendanceSummaryByUnit(date: String): Flow<List<com.example.data.model.UnitAttendanceSummary>> =
        attendanceDao.getAttendanceSummaryByUnit(date)

    fun getAllSoldiersIncludingInactive(): Flow<List<SoldierEntity>> =
        soldierDao.getAllSoldiersIncludingInactive()

    suspend fun transferSoldierToUnit(militaryId: String, newUnitId: Long): Boolean = withContext(Dispatchers.IO) {
        soldierDao.transferSoldierToUnit(militaryId, newUnitId) > 0
    }

    suspend fun addUnit(unitName: String, commanderName: String, codeSymbol: String): Long = withContext(Dispatchers.IO) {
        unitDao.insertUnit(
            UnitEntity(
                unitName = unitName.trim(),
                commanderName = commanderName.trim().ifEmpty { "قيادة العمليات" },
                codeSymbol = codeSymbol.trim().ifEmpty { "MIL-OPS" }
            )
        )
    }

    suspend fun editUnitName(unitId: Long, newName: String): Boolean = withContext(Dispatchers.IO) {
        unitDao.updateUnitName(unitId, newName.trim()) > 0
    }

    suspend fun editUnitDetails(
        unitId: Long,
        newName: String,
        commanderName: String,
        codeSymbol: String
    ): Boolean = withContext(Dispatchers.IO) {
        unitDao.updateUnitDetails(
            unitId = unitId,
            unitName = newName.trim(),
            commanderName = commanderName.trim().ifEmpty { "قيادة العمليات" },
            codeSymbol = codeSymbol.trim().ifEmpty { "MIL-OPS" }
        ) > 0
    }

    /**
     * Atomically reassigns a list of soldiers to a new unit in a single database transaction.
     */
    suspend fun reassignSoldiersBetweenUnitsTransaction(
        soldierIds: List<String>,
        targetUnitId: Long
    ): Boolean = withContext(Dispatchers.IO) {
        if (soldierIds.isEmpty()) return@withContext true
        database.withTransaction {
            soldierDao.reassignSoldiersBatch(soldierIds, targetUnitId)
            true
        }
    }

    /**
     * Atomically updates unit details and reassigns soldiers to/from that unit in a single database transaction.
     */
    suspend fun updateUnitAndReassignSoldiersTransaction(
        unitId: Long,
        newName: String,
        commanderName: String,
        codeSymbol: String,
        soldierIdsToReassign: List<String>
    ): Boolean = withContext(Dispatchers.IO) {
        database.withTransaction {
            val existing = unitDao.getUnitById(unitId) ?: return@withTransaction false
            val updated = existing.copy(
                unitName = newName.trim().ifEmpty { existing.unitName },
                commanderName = commanderName.trim().ifEmpty { existing.commanderName },
                codeSymbol = codeSymbol.trim().ifEmpty { existing.codeSymbol }
            )
            unitDao.updateUnit(updated)

            if (soldierIdsToReassign.isNotEmpty()) {
                soldierDao.reassignSoldiersBatch(soldierIdsToReassign, unitId)
            }
            true
        }
    }

    /**
     * Atomically deletes a unit and migrates all its assigned soldiers to a fallback unit.
     */
    suspend fun deleteUnitAndReassignSoldiersTransaction(
        unitIdToDelete: Long,
        fallbackUnitId: Long
    ): Boolean = withContext(Dispatchers.IO) {
        database.withTransaction {
            val soldiersInUnit = soldierDao.getSoldiersByUnitList(unitIdToDelete)
            if (soldiersInUnit.isNotEmpty()) {
                val ids = soldiersInUnit.map { it.militaryId }
                soldierDao.reassignSoldiersBatch(ids, fallbackUnitId)
            }
            unitDao.deleteUnitById(unitIdToDelete)
            true
        }
    }

    suspend fun getSoldiersForUnit(unitId: Long): List<SoldierEntity> = withContext(Dispatchers.IO) {
        soldierDao.getSoldiersByUnitList(unitId)
    }

    fun getAllUnits(): Flow<List<UnitEntity>> = unitDao.getAllUnits()

    suspend fun getAllSoldiersForReport(date: String, unitId: Long?): List<SoldierAttendanceItem> =
        withContext(Dispatchers.IO) {
            attendanceDao.getAllSoldiersWithAttendance(date, unitId)
        }

    fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
}
