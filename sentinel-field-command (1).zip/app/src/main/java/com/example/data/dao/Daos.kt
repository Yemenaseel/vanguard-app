package com.example.data.dao

import androidx.paging.PagingSource
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.AttendanceEntity
import com.example.data.model.AttendanceStatus
import com.example.data.model.SoldierAttendanceItem
import com.example.data.model.SoldierEntity
import com.example.data.model.UnitAttendanceSummary
import com.example.data.model.UnitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SoldierDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSoldier(soldier: SoldierEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSoldiers(soldiers: List<SoldierEntity>)

    @Update
    suspend fun updateSoldier(soldier: SoldierEntity)

    @Delete
    suspend fun deleteSoldier(soldier: SoldierEntity)

    @Query("DELETE FROM soldiers WHERE militaryId = :militaryId")
    suspend fun deleteSoldierByMilitaryId(militaryId: String): Int

    @Query("SELECT * FROM soldiers WHERE militaryId = :militaryId LIMIT 1")
    suspend fun findByMilitaryId(militaryId: String): SoldierEntity?

    @Query("SELECT * FROM soldiers WHERE qrToken = :qrToken LIMIT 1")
    suspend fun findByQrToken(qrToken: String): SoldierEntity?

    @Query("SELECT COUNT(*) FROM soldiers WHERE isActive = 1")
    suspend fun getActiveSoldierCount(): Int

    @Query("SELECT * FROM soldiers WHERE isActive = 1 ORDER BY militaryId ASC")
    fun getAllSoldiers(): Flow<List<SoldierEntity>>

    @Query("SELECT * FROM soldiers WHERE unitId = :unitId AND isActive = 1 ORDER BY militaryId ASC")
    fun getSoldiersByUnit(unitId: Long): Flow<List<SoldierEntity>>

    @Query("UPDATE soldiers SET isActive = :isActive WHERE militaryId = :militaryId")
    suspend fun setSoldierActiveStatus(militaryId: String, isActive: Boolean): Int

    @Query("UPDATE soldiers SET unitId = :newUnitId WHERE militaryId = :militaryId")
    suspend fun transferSoldierToUnit(militaryId: String, newUnitId: Long): Int

    @Query("UPDATE soldiers SET unitId = :newUnitId WHERE militaryId IN (:militaryIds)")
    suspend fun reassignSoldiersBatch(militaryIds: List<String>, newUnitId: Long): Int

    @Query("SELECT * FROM soldiers WHERE unitId = :unitId AND isActive = 1 ORDER BY militaryId ASC")
    suspend fun getSoldiersByUnitList(unitId: Long): List<SoldierEntity>

    @Query("UPDATE soldiers SET qrToken = :newQrToken WHERE militaryId = :militaryId")
    suspend fun reIssueQrToken(militaryId: String, newQrToken: String): Int

    @Query("SELECT * FROM soldiers ORDER BY militaryId ASC")
    fun getAllSoldiersIncludingInactive(): Flow<List<SoldierEntity>>

    /**
     * Sub-5ms Full-Text Search utilizing soldiers_fts virtual table.
     */
    @Query("""
        SELECT s.* FROM soldiers s
        JOIN soldiers_fts f ON s.militaryId = f.militaryId
        WHERE soldiers_fts MATCH :searchQuery AND s.isActive = 1
        ORDER BY s.militaryId ASC
    """)
    fun searchSoldiersFts(searchQuery: String): Flow<List<SoldierEntity>>
}

@Dao
interface AttendanceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordAttendance(attendance: AttendanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordAttendanceBatch(records: List<AttendanceEntity>)

    @Query("""
        SELECT * FROM attendance_records 
        WHERE militaryId = :militaryId AND date = :date 
        LIMIT 1
    """)
    suspend fun getAttendanceForSoldier(militaryId: String, date: String): AttendanceEntity?

    @Query("""
        SELECT * FROM attendance_records 
        WHERE militaryId = :militaryId AND date = :date 
        LIMIT 1
    """)
    fun getAttendanceFlowForSoldier(militaryId: String, date: String): Flow<AttendanceEntity?>

    @Query("""
        SELECT * FROM attendance_records 
        WHERE date = :date 
        ORDER BY timestamp DESC
    """)
    fun getAttendanceByDate(date: String): Flow<List<AttendanceEntity>>

    @Query("DELETE FROM attendance_records WHERE militaryId = :militaryId AND date = :date")
    suspend fun deleteAttendance(militaryId: String, date: String): Int

    @Query("DELETE FROM attendance_records WHERE date = :date")
    suspend fun clearAttendanceForDate(date: String): Int

    @Query("""
        SELECT * FROM attendance_records 
        WHERE militaryId = :militaryId 
        ORDER BY date DESC, timestamp DESC
    """)
    suspend fun getSoldierAttendanceHistory(militaryId: String): List<AttendanceEntity>

    @Query("""
        SELECT 
            u.unitId,
            u.unitName,
            COUNT(DISTINCT s.militaryId) AS totalSoldiers,
            COUNT(DISTINCT CASE WHEN a.status = 'PRESENT' THEN a.militaryId END) AS presentCount,
            COUNT(DISTINCT CASE WHEN a.status = 'ABSENT' THEN a.militaryId END) AS absentCount,
            COUNT(DISTINCT CASE WHEN a.status = 'SICK' THEN a.militaryId END) AS sickCount,
            COUNT(DISTINCT CASE WHEN a.status = 'LEAVE' THEN a.militaryId END) AS leaveCount,
            COUNT(DISTINCT CASE WHEN a.status = 'MISSION' THEN a.militaryId END) AS missionCount
        FROM units u
        LEFT JOIN soldiers s ON s.unitId = u.unitId AND s.isActive = 1
        LEFT JOIN attendance_records a ON a.militaryId = s.militaryId AND a.date = :date
        GROUP BY u.unitId, u.unitName
        ORDER BY u.unitId ASC
    """)
    fun getAttendanceSummaryByUnit(date: String): Flow<List<UnitAttendanceSummary>>

    @Query("""
        UPDATE attendance_records 
        SET status = :status, timestamp = :timestamp, recordedByRole = :role, markedByOfficerName = :officerName
        WHERE militaryId = :militaryId AND date = :date
    """)
    suspend fun updateAttendanceStatus(
        militaryId: String,
        date: String,
        status: AttendanceStatus,
        timestamp: Long,
        role: String,
        officerName: String
    ): Int

    /**
     * Paging 3 virtualized list query (handles 5,000+ records with constant memory footprint).
     * Connects soldiers, units, and daily attendance.
     */
    @Query("""
        SELECT 
            s.militaryId,
            s.fullName,
            s.rank,
            s.unitId,
            u.unitName,
            s.bloodType,
            s.assignedWeapon,
            s.qrToken,
            s.isActive,
            COALESCE(a.status, 'UNMARKED') AS attendanceStatus,
            a.timestamp AS attendanceTimestamp,
            a.recordedByRole AS recordedByRole,
            a.markedByOfficerName AS markedByOfficerName
        FROM soldiers s
        LEFT JOIN units u ON s.unitId = u.unitId
        LEFT JOIN attendance_records a ON s.militaryId = a.militaryId AND a.date = :date
        WHERE s.isActive = 1
          AND (:unitId IS NULL OR s.unitId = :unitId)
          AND (
            :query = '' 
            OR s.militaryId LIKE '%' || :query || '%' 
            OR s.fullName LIKE '%' || :query || '%' 
            OR s.rank LIKE '%' || :query || '%'
          )
        ORDER BY s.militaryId ASC
    """)
    fun getSoldiersWithAttendancePaging(
        date: String,
        unitId: Long?,
        query: String
    ): PagingSource<Int, SoldierAttendanceItem>

    /**
     * Non-paging query for PDF report export.
     */
    @Query("""
        SELECT 
            s.militaryId,
            s.fullName,
            s.rank,
            s.unitId,
            u.unitName,
            s.bloodType,
            s.assignedWeapon,
            s.qrToken,
            s.isActive,
            COALESCE(a.status, 'UNMARKED') AS attendanceStatus,
            a.timestamp AS attendanceTimestamp,
            a.recordedByRole AS recordedByRole,
            a.markedByOfficerName AS markedByOfficerName
        FROM soldiers s
        LEFT JOIN units u ON s.unitId = u.unitId
        LEFT JOIN attendance_records a ON s.militaryId = a.militaryId AND a.date = :date
        WHERE s.isActive = 1
          AND (:unitId IS NULL OR s.unitId = :unitId)
        ORDER BY s.unitId ASC, s.militaryId ASC
    """)
    suspend fun getAllSoldiersWithAttendance(date: String, unitId: Long?): List<SoldierAttendanceItem>

    /**
     * Atomically marks all active soldiers as PRESENT in a single SQLite transaction.
     */
    @Transaction
    suspend fun markAllActiveAsPresent(
        soldiers: List<SoldierEntity>,
        date: String,
        timestamp: Long,
        role: String,
        officerName: String
    ) {
        val records = soldiers.map {
            AttendanceEntity(
                militaryId = it.militaryId,
                date = date,
                timestamp = timestamp,
                status = AttendanceStatus.PRESENT,
                recordedByRole = role,
                markedByOfficerName = officerName
            )
        }
        recordAttendanceBatch(records)
    }

    /**
     * Real-time aggregate count for the commander metrics dashboard.
     */
    @Query("""
        SELECT 
            (SELECT COUNT(*) FROM soldiers WHERE isActive = 1) AS totalSoldiers,
            (SELECT COUNT(*) FROM attendance_records WHERE date = :date AND status = 'PRESENT') AS presentCount,
            (SELECT COUNT(*) FROM attendance_records WHERE date = :date AND status = 'ABSENT') AS absentCount,
            (SELECT COUNT(*) FROM attendance_records WHERE date = :date AND status = 'SICK') AS sickCount,
            (SELECT COUNT(*) FROM attendance_records WHERE date = :date AND status = 'LEAVE') AS leaveCount,
            (SELECT COUNT(*) FROM attendance_records WHERE date = :date AND status = 'MISSION') AS missionCount
    """)
    fun getDailyAttendanceCounts(date: String): Flow<DailyRawCounts>
}

data class DailyRawCounts(
    val totalSoldiers: Int,
    val presentCount: Int,
    val absentCount: Int,
    val sickCount: Int,
    val leaveCount: Int,
    val missionCount: Int
)

@Dao
interface UnitDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUnit(unit: UnitEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUnits(units: List<UnitEntity>)

    @Update
    suspend fun updateUnit(unit: UnitEntity)

    @Query("UPDATE units SET unitName = :unitName WHERE unitId = :unitId")
    suspend fun updateUnitName(unitId: Long, unitName: String): Int

    @Query("UPDATE units SET unitName = :unitName, commanderName = :commanderName, codeSymbol = :codeSymbol WHERE unitId = :unitId")
    suspend fun updateUnitDetails(unitId: Long, unitName: String, commanderName: String, codeSymbol: String): Int

    @Delete
    suspend fun deleteUnit(unit: UnitEntity)

    @Query("DELETE FROM units WHERE unitId = :unitId")
    suspend fun deleteUnitById(unitId: Long): Int

    @Query("SELECT * FROM units WHERE unitId = :unitId LIMIT 1")
    suspend fun getUnitById(unitId: Long): UnitEntity?

    @Query("SELECT * FROM units ORDER BY unitId ASC")
    fun getAllUnits(): Flow<List<UnitEntity>>

    @Query("SELECT * FROM units ORDER BY unitId ASC")
    suspend fun getAllUnitsList(): List<UnitEntity>

    @Query("SELECT COUNT(*) FROM units")
    suspend fun getUnitCount(): Int
}
