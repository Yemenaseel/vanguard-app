package com.example.data.model

import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Core Soldier Entity representing military personnel.
 * Indexed by qrToken (unique cryptographic token) and unitId for rapid retrieval.
 */
@Entity(
    tableName = "soldiers",
    indices = [
        Index(value = ["qrToken"], unique = true),
        Index(value = ["unitId"])
    ]
)
data class SoldierEntity(
    @PrimaryKey val militaryId: String,
    val fullName: String,
    val rank: String,
    val unitId: Long,
    val bloodType: String,
    val assignedWeapon: String,
    val qrToken: String, // Secure 128-bit Cryptographic Token (UUID v4 + HMAC)
    val isActive: Boolean = true
)

/**
 * Room FTS4 Virtual Table mapped to SoldierEntity for sub-5ms Full-Text Search.
 */
@Entity(tableName = "soldiers_fts")
@Fts4(contentEntity = SoldierEntity::class)
data class SoldierFtsEntity(
    val militaryId: String,
    val fullName: String,
    val rank: String
)

/**
 * Military Unit / Battalion / Company Entity
 */
@Entity(tableName = "units")
data class UnitEntity(
    @PrimaryKey(autoGenerate = true) val unitId: Long = 0,
    val unitName: String,
    val commanderName: String = "قيادة العمليات",
    val codeSymbol: String = "MIL-OPS"
)

/**
 * Daily Attendance Record Entity
 */
@Entity(
    tableName = "attendance_records",
    primaryKeys = ["militaryId", "date"],
    indices = [
        Index("date"),
        Index("status")
    ]
)
data class AttendanceEntity(
    val militaryId: String,
    val date: String, // YYYY-MM-DD
    val timestamp: Long,
    val status: AttendanceStatus, // PRESENT, ABSENT, SICK, LEAVE, MISSION, UNMARKED
    val recordedByRole: String, // "SCANNER_OFFICER" or "ADMIN_MANUAL"
    val markedByOfficerName: String
)

enum class AttendanceStatus(val labelAr: String, val labelEn: String) {
    PRESENT("حاضر", "Present"),
    ABSENT("غائب", "Absent"),
    SICK("مرض", "Sick"),
    LEAVE("إجازة", "Leave"),
    MISSION("مأمورية", "Mission"),
    UNMARKED("غير مسجل", "Unmarked")
}

enum class UserRole(val titleAr: String, val titleEn: String) {
    ROLE_RECORDER("ضابط رصد ميداني (قارئ QR)", "Field Officer (Scanner)"),
    ROLE_ADMIN("قائد الوحدة / المشرف العام", "Commander / High Admin")
}

/**
 * Composite view model for Paging list combining Soldier, Unit, and Today's Attendance.
 */
data class SoldierAttendanceItem(
    val militaryId: String,
    val fullName: String,
    val rank: String,
    val unitId: Long,
    val unitName: String?,
    val bloodType: String,
    val assignedWeapon: String,
    val qrToken: String,
    val isActive: Boolean,
    val attendanceStatus: AttendanceStatus,
    val attendanceTimestamp: Long?,
    val recordedByRole: String?,
    val markedByOfficerName: String?
)

/**
 * Daily Attendance Metrics Summary
 */
data class AttendanceSummary(
    val totalSoldiers: Int = 0,
    val presentCount: Int = 0,
    val absentCount: Int = 0,
    val sickCount: Int = 0,
    val leaveCount: Int = 0,
    val missionCount: Int = 0,
    val unmarkedCount: Int = 0
) {
    val presentPercentage: Float
        get() = if (totalSoldiers > 0) (presentCount.toFloat() / totalSoldiers) * 100f else 0f
}

/**
 * Breakdown of attendance statistics per military unit/battalion.
 */
data class UnitAttendanceSummary(
    val unitId: Long,
    val unitName: String,
    val totalSoldiers: Int,
    val presentCount: Int,
    val absentCount: Int,
    val sickCount: Int,
    val leaveCount: Int,
    val missionCount: Int
) {
    val presentPercentage: Float
        get() = if (totalSoldiers > 0) (presentCount.toFloat() / totalSoldiers) * 100f else 0f
}

/**
 * Model representing system officer/user for RBAC management.
 */
data class OfficerUser(
    val id: String,
    val name: String,
    val role: UserRole,
    val pin: String = "****"
)
