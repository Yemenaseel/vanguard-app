package com.example.data.db

import androidx.room.TypeConverter
import com.example.data.model.AttendanceStatus

class Converters {

    @TypeConverter
    fun fromAttendanceStatus(status: AttendanceStatus?): String {
        return status?.name ?: AttendanceStatus.UNMARKED.name
    }

    @TypeConverter
    fun toAttendanceStatus(value: String?): AttendanceStatus {
        return try {
            if (value != null) AttendanceStatus.valueOf(value) else AttendanceStatus.UNMARKED
        } catch (e: Exception) {
            AttendanceStatus.UNMARKED
        }
    }
}
