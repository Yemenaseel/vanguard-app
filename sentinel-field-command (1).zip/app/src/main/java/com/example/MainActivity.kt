package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.db.AppDatabase
import com.example.data.model.UserRole
import com.example.data.repository.RollCallRepository
import com.example.security.AuthManager
import com.example.ui.auth.LoginScreen
import com.example.ui.commander.CommanderAttendanceScreen
import com.example.ui.commander.UnitManagementScreen
import com.example.ui.report.ReportsScreen
import com.example.ui.scanner.ScannerScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RollCallViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val authManager = AuthManager(applicationContext)
        val database = AppDatabase.getInstance(applicationContext)
        val repository = RollCallRepository(
            database = database,
            soldierDao = database.soldierDao(),
            attendanceDao = database.attendanceDao(),
            unitDao = database.unitDao()
        )

        setContent {
            MyApplicationTheme {
                val rollCallViewModel: RollCallViewModel = viewModel(
                    factory = RollCallViewModel.Factory(repository, authManager)
                )
                val scannerViewModel: com.example.ui.scanner.ScannerViewModel = viewModel(
                    factory = com.example.ui.scanner.ScannerViewModel.Factory(repository, authManager)
                )

                Surface(modifier = Modifier.fillMaxSize()) {
                    MilRollCallApp(
                        authManager = authManager,
                        repository = repository,
                        rollCallViewModel = rollCallViewModel,
                        scannerViewModel = scannerViewModel
                    )
                }
            }
        }
    }
}

enum class ScreenState {
    LOGIN,
    SCANNER,
    COMMANDER_DASHBOARD,
    REPORTS,
    SETTINGS,
    UNIT_MANAGEMENT
}

@Composable
fun MilRollCallApp(
    authManager: AuthManager,
    repository: RollCallRepository,
    rollCallViewModel: RollCallViewModel,
    scannerViewModel: com.example.ui.scanner.ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val currentRole by authManager.currentRole.collectAsState()
    var commanderSubScreen by remember { mutableStateOf<ScreenState?>(null) }
    var recorderSubScreen by remember { mutableStateOf<ScreenState?>(null) }

    when {
        currentRole == null -> {
            LoginScreen(
                authManager = authManager,
                onLoginSuccess = { role ->
                    if (role == UserRole.ROLE_ADMIN) {
                        commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                    } else {
                        recorderSubScreen = ScreenState.SCANNER
                    }
                },
                modifier = modifier
            )
        }

        // ROLE_RECORDER (المشرف / ضابط الرصد) can perform scanning and review reports/results
        currentRole == UserRole.ROLE_RECORDER -> {
            when (recorderSubScreen) {
                ScreenState.REPORTS -> {
                    BackHandler {
                        recorderSubScreen = ScreenState.SCANNER
                    }
                    ReportsScreen(
                        authManager = authManager,
                        repository = repository,
                        onNavigateBack = {
                            recorderSubScreen = ScreenState.SCANNER
                        },
                        modifier = modifier
                    )
                }

                else -> {
                    BackHandler {
                        authManager.logout()
                    }
                    ScannerScreen(
                        authManager = authManager,
                        scannerViewModel = scannerViewModel,
                        onNavigateBack = {
                            authManager.logout()
                        },
                        onNavigateToReports = {
                            recorderSubScreen = ScreenState.REPORTS
                        },
                        modifier = modifier
                    )
                }
            }
        }

        // ROLE_ADMIN has Commander Dashboard and can navigate to Scanner, Reports, Settings
        currentRole == UserRole.ROLE_ADMIN -> {
            when (commanderSubScreen) {
                ScreenState.SCANNER -> {
                    BackHandler {
                        commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                    }
                    ScannerScreen(
                        authManager = authManager,
                        scannerViewModel = scannerViewModel,
                        onNavigateBack = {
                            commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                        },
                        modifier = modifier
                    )
                }

                ScreenState.REPORTS -> {
                    BackHandler {
                        commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                    }
                    ReportsScreen(
                        authManager = authManager,
                        repository = repository,
                        onNavigateBack = {
                            commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                        },
                        modifier = modifier
                    )
                }

                ScreenState.SETTINGS -> {
                    BackHandler {
                        commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                    }
                    SettingsScreen(
                        authManager = authManager,
                        repository = repository,
                        onNavigateBack = {
                            commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                        },
                        modifier = modifier
                    )
                }

                ScreenState.UNIT_MANAGEMENT -> {
                    BackHandler {
                        commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                    }
                    UnitManagementScreen(
                        authManager = authManager,
                        repository = repository,
                        onNavigateBack = {
                            commanderSubScreen = ScreenState.COMMANDER_DASHBOARD
                        },
                        modifier = modifier
                    )
                }

                else -> {
                    BackHandler {
                        authManager.logout()
                    }
                    CommanderAttendanceScreen(
                        authManager = authManager,
                        viewModel = rollCallViewModel,
                        onNavigateToScanner = {
                            commanderSubScreen = ScreenState.SCANNER
                        },
                        onNavigateToReports = {
                            commanderSubScreen = ScreenState.REPORTS
                        },
                        onNavigateToSettings = {
                            commanderSubScreen = ScreenState.SETTINGS
                        },
                        onNavigateToUnitManagement = {
                            commanderSubScreen = ScreenState.UNIT_MANAGEMENT
                        },
                        onLogout = {
                            authManager.logout()
                        },
                        modifier = modifier
                    )
                }
            }
        }
    }
}
